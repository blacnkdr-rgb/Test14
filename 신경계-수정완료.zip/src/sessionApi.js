const SESSION_ENDPOINT = '/.netlify/functions/session';

async function requestSession(url, options = {}) {
  const response = await fetch(url, {
    headers: {
      'Content-Type': 'application/json',
    },
    ...options,
  });

  const payload = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(payload.error || '세션 요청에 실패했습니다.');
  }

  return payload;
}

export function createSession(payload) {
  return requestSession(SESSION_ENDPOINT, {
    method: 'POST',
    body: JSON.stringify({
      action: 'create',
      payload,
    }),
  });
}

export function fetchSession(code) {
  return requestSession(`${SESSION_ENDPOINT}?code=${encodeURIComponent(code)}`);
}

export function runTeacherAction(code, teacherAction) {
  return requestSession(SESSION_ENDPOINT, {
    method: 'POST',
    body: JSON.stringify({
      action: 'teacherAction',
      code,
      teacherAction,
    }),
  });
}

export function submitSessionAnswer(code, payload) {
  return requestSession(SESSION_ENDPOINT, {
    method: 'POST',
    body: JSON.stringify({
      action: 'submitAnswer',
      code,
      payload,
    }),
  });
}
