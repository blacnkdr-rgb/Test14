﻿import React, { useState, useEffect, useRef } from 'react';
import {
  QUESTION_DURATION_SECONDS,
  SESSION_POLL_INTERVAL_MS,
  TEAM_COUNT,
  TOTAL_QUESTIONS,
  getDefaultTeamName,
} from './gameConfig';
import { createSession, fetchSession, runTeacherAction, submitSessionAnswer } from './sessionApi';

function normalizeSessionCode(value) {
  return String(value || '')
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, '')
    .slice(0, 6);
}

function buildTeamNumbers() {
  return Array.from({ length: TEAM_COUNT }, (_, index) => index + 1);
}

function getTeamLabel(teamNames, teamNumber) {
  return (
    teamNames?.[teamNumber] ||
    teamNames?.[String(teamNumber)] ||
    getDefaultTeamName(teamNumber)
  );
}

function getTeamAnswer(sessionData, teamNumber, questionIndex) {
  return sessionData?.answers?.[String(teamNumber)]?.[questionIndex] || null;
}

function getTeamScores(sessionData, teamNumber) {
  return sessionData?.scores?.[String(teamNumber)] || Array(TOTAL_QUESTIONS).fill(0);
}

function getLeaderboard(sessionData) {
  const currentQuestion = sessionData?.currentQuestion ?? 0;

  return buildTeamNumbers()
    .map((teamNumber) => {
      const scores = getTeamScores(sessionData, teamNumber);

      return {
        answer: getTeamAnswer(sessionData, teamNumber, currentQuestion),
        currentScore: scores[currentQuestion] || 0,
        number: teamNumber,
        total: scores.reduce((sum, score) => sum + score, 0),
      };
    })
    .sort((left, right) => right.total - left.total);
}

function getQuestionTimeLeft(deadlineAt) {
  if (!deadlineAt) {
    return QUESTION_DURATION_SECONDS;
  }

  return Math.max(0, Math.ceil((new Date(deadlineAt).getTime() - Date.now()) / 1000));
}

function buildSessionUrl(sessionCode, role) {
  if (typeof window === 'undefined') {
    return '';
  }

  const url = new URL(window.location.href);
  url.searchParams.set('session', sessionCode);
  url.searchParams.set('role', role);
  return url.toString();
}

function getCardVideoPath(cardNumber) {
  return `/videos/card${String(cardNumber).padStart(2, '0')}.mp4`;
}

function getVideoStepFromTime(currentTime, duration, stepCount) {
  if (!duration || !stepCount) {
    return 0;
  }

  const normalized = Math.min(0.999999, Math.max(0, currentTime / duration));
  return Math.min(stepCount - 1, Math.floor(normalized * stepCount));
}

function getVideoSeekTime(stepIndex, duration, stepCount) {
  if (!duration || stepCount <= 1) {
    return 0;
  }

  const ratio = stepIndex / (stepCount - 1);
  return Math.min(duration, Math.max(0, duration * ratio));
}

export default function NeuronMissionApp() {
  const [screen, setScreen] = useState('home');
  const [role, setRole] = useState(null);
  const [teamNames, setTeamNames] = useState({});
  const [selectedStudentTeam, setSelectedStudentTeam] = useState(null);
  const [activityTab, setActivityTab] = useState('conscious');
  const [sessionCode, setSessionCode] = useState('');
  const [sessionCodeInput, setSessionCodeInput] = useState('');
  const [sessionData, setSessionData] = useState(null);
  const [timeLeft, setTimeLeft] = useState(QUESTION_DURATION_SECONDS);
  const [errorMessage, setErrorMessage] = useState('');
  const [isBusy, setIsBusy] = useState(false);
  const [showCodeBoard, setShowCodeBoard] = useState(false);
  const pollRef = useRef(null);

  // ===== 의식적 반응 (6개) - 반드시 대뇌를 거침 =====
  const consciousProblems = [
    {
      id: 0,
      title: '🏃 출발 신호 소리를 듣고 달리기 시작하기',
      description: '운동회에서 출발 신호를 듣고 뇌에서 판단한 후 의도적으로 달리기를 시작합니다.',
      emoji: '🔊👂🧠🏃',
      type: 'conscious',
      correctSequence: ['출발 신호 소리', '귀', '감각 신경', '대뇌', '척수', '운동 신경', '다리 근육', '달리기'],
      beforeImage: 'https://i.imgur.com/before1.jpg',
      afterImage: 'https://i.imgur.com/after1.jpg',
      animationSteps: [
        { icon: '🔊', label: '출발 신호 소리', description: '출발 신호 소리가 들립니다.' },
        { icon: '👂', label: '귀', description: '귀가 소리를 감지합니다.' },
        { icon: '⚡', label: '감각 신경', description: '감각 신경이 신호를 뇌로 전달합니다.' },
        { icon: '🧠', label: '대뇌', description: '대뇌가 신호를 인식하고 달리라고 판단합니다. (의식적 결정!)' },
        { icon: '⚡', label: '운동 신경', description: '운동 신경이 명령을 다리로 전달합니다.' },
        { icon: '💪', label: '다리 근육', description: '다리 근육이 수축합니다.' },
        { icon: '🏃', label: '달리기', description: '의도적으로 달리기를 시작합니다!' }
      ],
      allCards: [
        { id: 1, text: '출발 신호 소리', type: 'correct' },
        { id: 2, text: '귀', type: 'correct' },
        { id: 3, text: '감각 신경', type: 'correct' },
        { id: 4, text: '대뇌', type: 'correct' },
        { id: 5, text: '운동 신경', type: 'correct' },
        { id: 6, text: '다리 근육', type: 'correct' },
        { id: 7, text: '달리기', type: 'correct' },
        { id: 8, text: '눈', type: 'trap' },
        { id: 9, text: '코', type: 'trap' },
        { id: 10, text: '손가락', type: 'trap' },
        { id: 11, text: '팔 근육', type: 'trap' },
        { id: 12, text: '입', type: 'trap' },
      ]
    },
    {
      id: 1,
      title: '📖 어려운 문제를 보고 풀이 방법을 생각한 뒤 답 쓰기',
      description: '복잡한 수학 문제를 보고 대뇌에서 생각한 후 의도적으로 손으로 답을 씁니다.',
      emoji: '📖🤔✏️',
      type: 'conscious',
      correctSequence: ['문제', '눈', '감각 신경', '대뇌', '척수', '운동 신경', '손 근육', '답 쓰기'],
      beforeImage: 'https://i.imgur.com/before2.jpg',
      afterImage: 'https://i.imgur.com/after2.jpg',
      animationSteps: [
        { icon: '📖', label: '문제', description: '어려운 문제가 보입니다.' },
        { icon: '👁️', label: '눈', description: '눈이 문제를 감지합니다.' },
        { icon: '⚡', label: '감각 신경', description: '감각 신경이 정보를 뇌로 전달합니다.' },
        { icon: '🧠', label: '대뇌', description: '대뇌에서 풀이 방법을 생각합니다. (의식적 판단!)' },
        { icon: '⚡', label: '운동 신경', description: '운동 신경이 명령을 손으로 전달합니다.' },
        { icon: '💪', label: '손 근육', description: '손 근육이 움직입니다.' },
        { icon: '✏️', label: '답 쓰기', description: '의도적으로 답을 씁니다!' }
      ],
      allCards: [
        { id: 1, text: '문제', type: 'correct' },
        { id: 2, text: '눈', type: 'correct' },
        { id: 3, text: '감각 신경', type: 'correct' },
        { id: 4, text: '대뇌', type: 'correct' },
        { id: 5, text: '운동 신경', type: 'correct' },
        { id: 6, text: '손 근육', type: 'correct' },
        { id: 7, text: '답 쓰기', type: 'correct' },
        { id: 8, text: '귀', type: 'trap' },
        { id: 9, text: '코', type: 'trap' },
        { id: 10, text: '다리 근육', type: 'trap' },
        { id: 11, text: '입 근육', type: 'trap' },
        { id: 12, text: '목 근육', type: 'trap' },
      ]
    },
    {
      id: 2,
      title: '🎁 선물을 받고 고맙다고 말하기',
      description: '선물을 받은 후 대뇌에서 감정을 느끼고 의도적으로 감사의 말을 합니다.',
      emoji: '🎁😊💬',
      type: 'conscious',
      correctSequence: ['선물', '눈', '감각 신경', '대뇌', '척수', '운동 신경', '입 근육', '감사말'],
      beforeImage: 'https://i.imgur.com/before3.jpg',
      afterImage: 'https://i.imgur.com/after3.jpg',
      animationSteps: [
        { icon: '🎁', label: '선물', description: '선물을 받습니다.' },
        { icon: '👁️', label: '눈', description: '눈이 선물을 감지합니다.' },
        { icon: '⚡', label: '감각 신경', description: '감각 신경이 정보를 뇌로 전달합니다.' },
        { icon: '🧠', label: '대뇌', description: '대뇌에서 고마운 감정을 느낍니다. (의식적 감정!)' },
        { icon: '⚡', label: '운동 신경', description: '운동 신경이 명령을 입 근육으로 전달합니다.' },
        { icon: '💪', label: '입 근육', description: '입 근육이 움직입니다.' },
        { icon: '💬', label: '감사말', description: '의도적으로 "고맙습니다"라고 말합니다!' }
      ],
      allCards: [
        { id: 1, text: '선물', type: 'correct' },
        { id: 2, text: '눈', type: 'correct' },
        { id: 3, text: '감각 신경', type: 'correct' },
        { id: 4, text: '대뇌', type: 'correct' },
        { id: 5, text: '운동 신경', type: 'correct' },
        { id: 6, text: '입 근육', type: 'correct' },
        { id: 7, text: '감사말', type: 'correct' },
        { id: 8, text: '척수', type: 'trap' },
        { id: 9, text: '귀', type: 'trap' },
        { id: 10, text: '코', type: 'trap' },
        { id: 11, text: '다리 근육', type: 'trap' },
        { id: 12, text: '손 근육', type: 'trap' },
        { id: 13, text: '목 근육', type: 'trap' },
      ]
    },
    {
      id: 3,
      title: '🎮 게임 화면을 보고 필요한 아이템을 골라 구매하기',
      description: '게임 화면을 보고 대뇌에서 판단한 후 필요한 아이템을 의도적으로 선택합니다.',
      emoji: '🎮👁️💭',
      type: 'conscious',
      correctSequence: ['게임 화면', '눈', '감각 신경', '대뇌', '척수', '운동 신경', '손가락', '아이템 구매'],
      beforeImage: 'https://i.imgur.com/before4.jpg',
      afterImage: 'https://i.imgur.com/after4.jpg',
      animationSteps: [
        { icon: '🎮', label: '게임 화면', description: '게임 화면이 보입니다.' },
        { icon: '👁️', label: '눈', description: '눈이 아이템들을 감지합니다.' },
        { icon: '⚡', label: '감각 신경', description: '감각 신경이 정보를 뇌로 전달합니다.' },
        { icon: '🧠', label: '대뇌', description: '대뇌가 필요한 아이템을 판단합니다. (의식적 선택!)' },
        { icon: '⚡', label: '운동 신경', description: '운동 신경이 명령을 손가락으로 전달합니다.' },
        { icon: '💪', label: '손가락', description: '손가락이 움직입니다.' },
        { icon: '✅', label: '아이템 구매', description: '의도적으로 아이템을 구매합니다!' }
      ],
      allCards: [
        { id: 1, text: '게임 화면', type: 'correct' },
        { id: 2, text: '눈', type: 'correct' },
        { id: 3, text: '감각 신경', type: 'correct' },
        { id: 4, text: '대뇌', type: 'correct' },
        { id: 5, text: '운동 신경', type: 'correct' },
        { id: 6, text: '손가락', type: 'correct' },
        { id: 7, text: '아이템 구매', type: 'correct' },
        { id: 8, text: '척수', type: 'trap' },
        { id: 9, text: '귀', type: 'trap' },
        { id: 10, text: '코', type: 'trap' },
        { id: 11, text: '다리 근육', type: 'trap' },
        { id: 12, text: '입 근육', type: 'trap' },
        { id: 13, text: '목 근육', type: 'trap' },
      ]
    },
    {
      id: 4,
      title: '🚌 버스 번호를 확인하고 타야 할 버스를 고르기',
      description: '버스 번호를 보고 대뇌에서 확인한 후 의도적으로 올바른 버스에 탑승합니다.',
      emoji: '🚌👀🧠',
      type: 'conscious',
      correctSequence: ['버스 번호', '눈', '감각 신경', '대뇌', '척수', '운동 신경', '다리 근육', '버스 탑승'],
      beforeImage: 'https://i.imgur.com/before5.jpg',
      afterImage: 'https://i.imgur.com/after5.jpg',
      animationSteps: [
        { icon: '🚌', label: '버스 번호', description: '버스 번호 표지판이 보입니다.' },
        { icon: '👁️', label: '눈', description: '눈이 버스 번호를 감지합니다.' },
        { icon: '⚡', label: '감각 신경', description: '감각 신경이 정보를 뇌로 전달합니다.' },
        { icon: '🧠', label: '대뇌', description: '대뇌가 올바른 버스를 판단합니다. (의식적 선택!)' },
        { icon: '⚡', label: '운동 신경', description: '운동 신경이 명령을 다리로 전달합니다.' },
        { icon: '💪', label: '다리 근육', description: '다리 근육이 움직입니다.' },
        { icon: '🚌', label: '버스 탑승', description: '의도적으로 버스에 탑승합니다!' }
      ],
      allCards: [
        { id: 1, text: '버스 번호', type: 'correct' },
        { id: 2, text: '눈', type: 'correct' },
        { id: 3, text: '감각 신경', type: 'correct' },
        { id: 4, text: '대뇌', type: 'correct' },
        { id: 5, text: '운동 신경', type: 'correct' },
        { id: 6, text: '다리 근육', type: 'correct' },
        { id: 7, text: '버스 탑승', type: 'correct' },
        { id: 8, text: '척수', type: 'trap' },
        { id: 9, text: '귀', type: 'trap' },
        { id: 10, text: '코', type: 'trap' },
        { id: 11, text: '손 근육', type: 'trap' },
        { id: 12, text: '입 근육', type: 'trap' },
        { id: 13, text: '목 근육', type: 'trap' },
      ]
    },
    {
      id: 5,
      title: '✋ 선생님의 질문을 듣고 생각한 뒤 손 들어 대답하기',
      description: '선생님의 질문을 듣고 대뇌에서 생각한 후 의도적으로 손을 들어 답합니다.',
      emoji: '👂🤔✋',
      type: 'conscious',
      correctSequence: ['선생님 질문', '귀', '감각 신경', '대뇌', '척수', '운동 신경', '팔 근육', '손 들기'],
      beforeImage: 'https://i.imgur.com/before6.jpg',
      afterImage: 'https://i.imgur.com/after6.jpg',
      animationSteps: [
        { icon: '👨‍🏫', label: '선생님 질문', description: '선생님이 질문을 합니다.' },
        { icon: '👂', label: '귀', description: '귀가 질문을 감지합니다.' },
        { icon: '⚡', label: '감각 신경', description: '감각 신경이 정보를 뇌로 전달합니다.' },
        { icon: '🧠', label: '대뇌', description: '대뇌에서 답을 생각합니다. (의식적 사고!)' },
        { icon: '⚡', label: '운동 신경', description: '운동 신경이 명령을 팔로 전달합니다.' },
        { icon: '💪', label: '팔 근육', description: '팔 근육이 움직입니다.' },
        { icon: '✋', label: '손 들기', description: '의도적으로 손을 들어 대답합니다!' }
      ],
      allCards: [
        { id: 1, text: '선생님 질문', type: 'correct' },
        { id: 2, text: '귀', type: 'correct' },
        { id: 3, text: '감각 신경', type: 'correct' },
        { id: 4, text: '대뇌', type: 'correct' },
        { id: 5, text: '운동 신경', type: 'correct' },
        { id: 6, text: '팔 근육', type: 'correct' },
        { id: 7, text: '손 들기', type: 'correct' },
        { id: 8, text: '척수', type: 'trap' },
        { id: 9, text: '눈', type: 'trap' },
        { id: 10, text: '코', type: 'trap' },
        { id: 11, text: '다리 근육', type: 'trap' },
        { id: 12, text: '입 근육', type: 'trap' },
        { id: 13, text: '목 근육', type: 'trap' },
      ]
    }
  ];

  // ===== 무조건 반사 (6개) - 척수(2개) + 연수(2개) + 중간뇌(2개) =====
  const unconditionalReflexProblems = [
    {
      id: 0,
      title: '🦵 무릎 아래를 두드리면 다리가 올라가기',
      description: '의사가 무릎 아래를 두드리자마다 반사적으로 다리가 펴집니다.',
      emoji: '🔨🦵⚡',
      type: 'unconditional',
      correctSequence: ['무릎 자극', '무릎 신경', '척수', '척수 반사', '운동 신경', '다리 근육', '다리 펴짐'],
      beforeImage: 'https://i.imgur.com/before7.jpg',
      afterImage: 'https://i.imgur.com/after7.jpg',
      animationSteps: [
        { icon: '🔨', label: '무릎 자극', description: '무릎 아래가 두드려집니다.' },
        { icon: '⚡', label: '무릎 신경', description: '무릎 신경이 자극을 감지합니다.' },
        { icon: '⬇️', label: '척수', description: '신경 신호가 전달되어 도달합니다.' },
        { icon: '♻️', label: '척수 반사', description: '반사 중추에서 즉시 반응합니다. (뇌를 거치지 않음!)' },
        { icon: '⚡', label: '운동 신경', description: '운동 신경이 다리로 신호를 보냅니다.' },
        { icon: '💪', label: '다리 근육', description: '다리 근육이 수축합니다.' },
        { icon: '🦵', label: '다리 펴짐', description: '의식 없이 자동으로 다리가 펴집니다!' }
      ],
      allCards: [
        { id: 1, text: '무릎 자극', type: 'correct' },
        { id: 2, text: '무릎 신경', type: 'correct' },
        { id: 3, text: '척수 반사', type: 'correct' },
        { id: 4, text: '운동 신경', type: 'correct' },
        { id: 5, text: '다리 근육', type: 'correct' },
        { id: 6, text: '다리 펴짐', type: 'correct' },
        { id: 7, text: '척수', type: 'trap' },
        { id: 8, text: '대뇌', type: 'trap' },
        { id: 9, text: '눈', type: 'trap' },
        { id: 10, text: '귀', type: 'trap' },
        { id: 11, text: '손가락 근육', type: 'trap' },
        { id: 12, text: '입 근육', type: 'trap' },
        { id: 13, text: '목 근육', type: 'trap' },
      ]
    },
    {
      id: 1,
      title: '🔥 뜨거운 물체를 만지자마자 손 떼기',
      description: '뜨거운 물건을 만지자마자 반사적으로 손을 뺍니다.',
      emoji: '🔥🖐️💨',
      type: 'unconditional',
      correctSequence: ['뜨거운 자극', '손가락', '감각 신경', '척수', '척수 반사', '운동 신경', '손 근육', '손 떼기'],
      beforeImage: 'https://i.imgur.com/before8.jpg',
      afterImage: 'https://i.imgur.com/after8.jpg',
      animationSteps: [
        { icon: '🔥', label: '뜨거운 자극', description: '뜨거운 물체가 손에 닿습니다.' },
        { icon: '🖐️', label: '손가락', description: '손가락이 열 자극을 감지합니다.' },
        { icon: '⚡', label: '감각 신경', description: '감각 신경이 신호를 보냅니다.' },
        { icon: '⬇️', label: '척수', description: '신경 신호가 전달되어 도달합니다.' },
        { icon: '♻️', label: '척수 반사', description: '반사 중추에서 즉시 반응합니다. (뇌를 거치지 않음!)' },
        { icon: '⚡', label: '운동 신경', description: '운동 신경이 손 근육으로 신호를 보냅니다.' },
        { icon: '💪', label: '손 근육', description: '손 근육이 수축합니다.' },
        { icon: '✋', label: '손 떼기', description: '의식 없이 빠르게 손을 뺍니다!' }
      ],
      allCards: [
        { id: 1, text: '뜨거운 자극', type: 'correct' },
        { id: 2, text: '손가락', type: 'correct' },
        { id: 3, text: '감각 신경', type: 'correct' },
        { id: 4, text: '척수 반사', type: 'correct' },
        { id: 5, text: '운동 신경', type: 'correct' },
        { id: 6, text: '손 근육', type: 'correct' },
        { id: 7, text: '손 떼기', type: 'correct' },
        { id: 8, text: '척수', type: 'trap' },
        { id: 9, text: '대뇌', type: 'trap' },
        { id: 10, text: '눈', type: 'trap' },
        { id: 11, text: '귀', type: 'trap' },
        { id: 12, text: '다리 근육', type: 'trap' },
        { id: 13, text: '입 근육', type: 'trap' },
      ]
    },
    {
      id: 2,
      title: '💨 먼지가 코에 들어오자 재채기하기',
      description: '먼지가 코에 들어오자 의식 없이 재채기가 자동으로 나옵니다.',
      emoji: '💨👃🤧',
      type: 'unconditional',
      correctSequence: ['먼지 자극', '코', '감각 신경', '연수', '연수 반사', '운동 신경', '호흡 근육', '재채기'],
      beforeImage: 'https://i.imgur.com/before9.jpg',
      afterImage: 'https://i.imgur.com/after9.jpg',
      animationSteps: [
        { icon: '💨', label: '먼지 자극', description: '먼지가 코에 들어옵니다.' },
        { icon: '👃', label: '코', description: '코가 먼지를 감지합니다.' },
        { icon: '⚡', label: '감각 신경', description: '감각 신경이 신호를 보냅니다.' },
        { icon: '🧠', label: '연수', description: '반사 중추가 작동합니다. (자동 반응!)' },
        { icon: '♻️', label: '연수 반사', description: '반사 중추가 즉시 반응합니다.' },
        { icon: '⚡', label: '운동 신경', description: '운동 신경이 호흡 근육으로 신호를 보냅니다.' },
        { icon: '💪', label: '호흡 근육', description: '호흡 근육들이 수축합니다.' },
        { icon: '🤧', label: '재채기', description: '의식 없이 자동으로 재채기가 나옵니다!' }
      ],
      allCards: [
        { id: 1, text: '먼지 자극', type: 'correct' },
        { id: 2, text: '코', type: 'correct' },
        { id: 3, text: '감각 신경', type: 'correct' },
        { id: 4, text: '연수 반사', type: 'correct' },
        { id: 5, text: '운동 신경', type: 'correct' },
        { id: 6, text: '호흡 근육', type: 'correct' },
        { id: 7, text: '재채기', type: 'correct' },
        { id: 8, text: '연수', type: 'trap' },
        { id: 9, text: '대뇌', type: 'trap' },
        { id: 10, text: '눈', type: 'trap' },
        { id: 11, text: '귀', type: 'trap' },
        { id: 12, text: '손 근육', type: 'trap' },
        { id: 13, text: '다리 근육', type: 'trap' },
      ]
    },
    {
      id: 3,
      title: '🤧 목에 이물질이 들어가 기침하기',
      description: '목에 이물질이 들어가자 의식 없이 기침이 자동으로 나옵니다.',
      emoji: '🫁👄🤧',
      type: 'unconditional',
      correctSequence: ['이물질 자극', '목', '감각 신경', '연수', '연수 반사', '운동 신경', '호흡 근육', '기침'],
      beforeImage: 'https://i.imgur.com/before10.jpg',
      afterImage: 'https://i.imgur.com/after10.jpg',
      animationSteps: [
        { icon: '👄', label: '이물질 자극', description: '이물질이 목에 들어옵니다.' },
        { icon: '🫁', label: '목', description: '목이 이물질을 감지합니다.' },
        { icon: '⚡', label: '감각 신경', description: '감각 신경이 신호를 보냅니다.' },
        { icon: '🧠', label: '연수', description: '반사 중추가 작동합니다. (자동 반응!)' },
        { icon: '♻️', label: '연수 반사', description: '반사 중추가 즉시 반응합니다.' },
        { icon: '⚡', label: '운동 신경', description: '운동 신경이 호흡 근육으로 신호를 보냅니다.' },
        { icon: '💪', label: '호흡 근육', description: '호흡 근육들이 수축합니다.' },
        { icon: '🤧', label: '기침', description: '의식 없이 자동으로 기침이 나옵니다!' }
      ],
      allCards: [
        { id: 1, text: '이물질 자극', type: 'correct' },
        { id: 2, text: '목', type: 'correct' },
        { id: 3, text: '감각 신경', type: 'correct' },
        { id: 4, text: '연수 반사', type: 'correct' },
        { id: 5, text: '운동 신경', type: 'correct' },
        { id: 6, text: '호흡 근육', type: 'correct' },
        { id: 7, text: '기침', type: 'correct' },
        { id: 8, text: '연수', type: 'trap' },
        { id: 9, text: '대뇌', type: 'trap' },
        { id: 10, text: '눈', type: 'trap' },
        { id: 11, text: '귀', type: 'trap' },
        { id: 12, text: '손 근육', type: 'trap' },
        { id: 13, text: '다리 근육', type: 'trap' },
      ]
    },
    {
      id: 4,
      title: '👁️ 물체가 갑자기 가까이 오면 눈 깜빡이기',
      description: '물체가 갑자기 눈 가까이 다가오자 의식 없이 눈 깜빡임이 자동으로 일어납니다.',
      emoji: '👀💨👁️',
      type: 'unconditional',
      correctSequence: ['물체 접근', '눈', '감각 신경', '중간뇌', '중간뇌 반사', '운동 신경', '눈 근육', '눈 깜빡임'],
      beforeImage: 'https://i.imgur.com/before11.jpg',
      afterImage: 'https://i.imgur.com/after11.jpg',
      animationSteps: [
        { icon: '💨', label: '물체 접근', description: '물체가 눈 가까이 다가옵니다.' },
        { icon: '👁️', label: '눈', description: '눈이 물체 접근을 감지합니다.' },
        { icon: '⚡', label: '감각 신경', description: '감각 신경이 신호를 보냅니다.' },
        { icon: '🧠', label: '중간뇌', description: '반사 중추가 작동합니다. (자동 반응!)' },
        { icon: '♻️', label: '중간뇌 반사', description: '반사 중추가 즉시 반응합니다.' },
        { icon: '⚡', label: '운동 신경', description: '운동 신경이 눈 근육으로 신호를 보냅니다.' },
        { icon: '💪', label: '눈 근육', description: '눈 근육이 수축합니다.' },
        { icon: '👁️', label: '눈 깜빡임', description: '의식 없이 자동으로 눈이 깜빡입니다!' }
      ],
      allCards: [
        { id: 1, text: '물체 접근', type: 'correct' },
        { id: 2, text: '눈', type: 'correct' },
        { id: 3, text: '감각 신경', type: 'correct' },
        { id: 4, text: '중간뇌 반사', type: 'correct' },
        { id: 5, text: '운동 신경', type: 'correct' },
        { id: 6, text: '눈 근육', type: 'correct' },
        { id: 7, text: '눈 깜빡임', type: 'correct' },
        { id: 8, text: '중간뇌', type: 'trap' },
        { id: 9, text: '대뇌', type: 'trap' },
        { id: 10, text: '귀', type: 'trap' },
        { id: 11, text: '코', type: 'trap' },
        { id: 12, text: '손 근육', type: 'trap' },
        { id: 13, text: '다리 근육', type: 'trap' },
      ]
    },
    {
      id: 5,
      title: '🔦 밝은 빛을 보면 동공이 작아지기',
      description: '밝은 빛이 나타나자 의식 없이 동공 축소가 자동으로 일어납니다.',
      emoji: '💡👁️✨',
      type: 'unconditional',
      correctSequence: ['밝은 빛', '눈', '감각 신경', '중간뇌', '중간뇌 반사', '운동 신경', '눈 근육', '동공 축소'],
      beforeImage: 'https://i.imgur.com/before12.jpg',
      afterImage: 'https://i.imgur.com/after12.jpg',
      animationSteps: [
        { icon: '💡', label: '밝은 빛', description: '밝은 빛이 눈에 들어옵니다.' },
        { icon: '👁️', label: '눈', description: '눈이 밝기를 감지합니다.' },
        { icon: '⚡', label: '감각 신경', description: '감각 신경이 신호를 보냅니다.' },
        { icon: '🧠', label: '중간뇌', description: '반사 중추가 작동합니다. (자동 반응!)' },
        { icon: '♻️', label: '중간뇌 반사', description: '반사 중추가 즉시 반응합니다.' },
        { icon: '⚡', label: '운동 신경', description: '운동 신경이 눈 근육으로 신호를 보냅니다.' },
        { icon: '💪', label: '눈 근육', description: '눈 근육이 수축합니다.' },
        { icon: '⚫', label: '동공 축소', description: '의식 없이 자동으로 동공이 작아집니다!' }
      ],
      allCards: [
        { id: 1, text: '밝은 빛', type: 'correct' },
        { id: 2, text: '눈', type: 'correct' },
        { id: 3, text: '감각 신경', type: 'correct' },
        { id: 4, text: '중간뇌 반사', type: 'correct' },
        { id: 5, text: '운동 신경', type: 'correct' },
        { id: 6, text: '눈 근육', type: 'correct' },
        { id: 7, text: '동공 축소', type: 'correct' },
        { id: 8, text: '중간뇌', type: 'trap' },
        { id: 9, text: '대뇌', type: 'trap' },
        { id: 10, text: '귀', type: 'trap' },
        { id: 11, text: '코', type: 'trap' },
        { id: 12, text: '손 근육', type: 'trap' },
        { id: 13, text: '다리 근육', type: 'trap' },
      ]
    }
  ];

  const consciousProblemsWithMedia = consciousProblems.map((problem, index) => ({
    ...problem,
    videoSrc: getCardVideoPath(index + 1),
  }));

  const unconditionalReflexProblemsWithMedia = unconditionalReflexProblems.map((problem, index) => ({
    ...problem,
    videoSrc: getCardVideoPath(index + 7),
  }));

  const sessionTeamNames = sessionData?.teamNames || teamNames;
  const problems =
    (sessionData?.activityTab || activityTab) === 'conscious'
      ? consciousProblemsWithMedia
      : unconditionalReflexProblemsWithMedia;
  const currentQuestion = sessionData?.currentQuestion ?? 0;
  const currentProblem = problems[currentQuestion] || problems[0];
  const leaderboard = sessionData ? getLeaderboard(sessionData) : [];
  const answeredCount = sessionData
    ? buildTeamNumbers().filter((teamNumber) => getTeamAnswer(sessionData, teamNumber, currentQuestion))
        .length
    : 0;
  const selectedTeamAnswer =
    selectedStudentTeam === null
      ? null
      : getTeamAnswer(sessionData, selectedStudentTeam, currentQuestion);
  const shareUrl = sessionCode ? buildSessionUrl(sessionCode, 'student') : '';

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const codeFromUrl = normalizeSessionCode(params.get('session'));
    const roleFromUrl = params.get('role');

    if (!codeFromUrl) {
      return;
    }

    setSessionCode(codeFromUrl);
    setSessionCodeInput(codeFromUrl);

    if (roleFromUrl === 'teacher') {
      setRole('teacher');
    } else {
      setRole('student');
      setScreen('studentJoin');
    }
  }, []);

  useEffect(() => {
    if (!sessionCode) {
      return undefined;
    }

    let cancelled = false;

    const syncSession = async () => {
      try {
        const response = await fetchSession(sessionCode);
        if (cancelled) {
          return;
        }

        setSessionData(response.session);
        setErrorMessage('');
      } catch (error) {
        if (cancelled) {
          return;
        }

        setErrorMessage(error.message);

        if (pollRef.current) {
          clearInterval(pollRef.current);
          pollRef.current = null;
        }
      }
    };

    syncSession();
    pollRef.current = window.setInterval(syncSession, SESSION_POLL_INTERVAL_MS);

    return () => {
      cancelled = true;

      if (pollRef.current) {
        clearInterval(pollRef.current);
        pollRef.current = null;
      }
    };
  }, [sessionCode]);

  useEffect(() => {
    if (sessionData?.phase !== 'mission' || !sessionData.questionDeadlineAt) {
      setTimeLeft(QUESTION_DURATION_SECONDS);
      return undefined;
    }

    const updateTimeLeft = () => {
      setTimeLeft(getQuestionTimeLeft(sessionData.questionDeadlineAt));
    };

    updateTimeLeft();
    const intervalId = window.setInterval(updateTimeLeft, 1000);

    return () => clearInterval(intervalId);
  }, [sessionData?.phase, sessionData?.questionDeadlineAt]);

  const updateSessionUrl = (nextCode, nextRole) => {
    const params = new URLSearchParams(window.location.search);

    if (nextCode) {
      params.set('session', nextCode);
    } else {
      params.delete('session');
    }

    if (nextRole) {
      params.set('role', nextRole);
    } else {
      params.delete('role');
    }

    const nextQuery = params.toString();
    const nextUrl = `${window.location.pathname}${nextQuery ? `?${nextQuery}` : ''}`;
    window.history.replaceState({}, '', nextUrl);
  };

  const goHome = () => {
    setScreen('home');
    setRole(null);
    setSessionCode('');
    setSessionCodeInput('');
    setSessionData(null);
    setSelectedStudentTeam(null);
    setTeamNames({});
    setErrorMessage('');
    setShowCodeBoard(false);
    updateSessionUrl('', null);
  };

  const handleCreateSession = async () => {
    setIsBusy(true);
    setErrorMessage('');

    try {
      const preparedTeamNames = {};

      buildTeamNumbers().forEach((teamNumber) => {
        preparedTeamNames[String(teamNumber)] =
          String(teamNames[teamNumber] || '').trim() || getDefaultTeamName(teamNumber);
      });

      const response = await createSession({
        activityTab,
        teamNames: preparedTeamNames,
      });

      setRole('teacher');
      setSessionCode(response.session.sessionCode);
      setSessionCodeInput(response.session.sessionCode);
      setSessionData(response.session);
      updateSessionUrl(response.session.sessionCode, 'teacher');
    } catch (error) {
      setErrorMessage(error.message);
    } finally {
      setIsBusy(false);
    }
  };

  const handleJoinSession = async () => {
    const normalizedCode = normalizeSessionCode(sessionCodeInput);

    if (!normalizedCode) {
      setErrorMessage('세션 코드를 입력해 주세요.');
      return;
    }

    setIsBusy(true);
    setErrorMessage('');

    try {
      const response = await fetchSession(normalizedCode);
      setRole('student');
      setSessionCode(normalizedCode);
      setSessionCodeInput(normalizedCode);
      setSessionData(response.session);
      setSelectedStudentTeam(null);
      updateSessionUrl(normalizedCode, 'student');
    } catch (error) {
      setErrorMessage(error.message);
    } finally {
      setIsBusy(false);
    }
  };

  const handleTeacherAction = async (teacherAction) => {
    if (!sessionCode) {
      return;
    }

    setIsBusy(true);
    setErrorMessage('');

    try {
      const response = await runTeacherAction(sessionCode, teacherAction);
      setSessionData(response.session);
    } catch (error) {
      setErrorMessage(error.message);
    } finally {
      setIsBusy(false);
    }
  };

  const handleSubmitAnswer = async (sequence) => {
    if (!sessionCode || selectedStudentTeam === null) {
      return;
    }

    setIsBusy(true);
    setErrorMessage('');

    try {
      const response = await submitSessionAnswer(sessionCode, {
        sequence,
        teamIdx: selectedStudentTeam,
      });
      setSessionData(response.session);
    } catch (error) {
      setErrorMessage(error.message);
    } finally {
      setIsBusy(false);
    }
  };
  if (role === 'teacher' && sessionCode) {
    if (!sessionData) {
      return (
        <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-400 to-pink-400 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl p-8 max-w-xl w-full text-center">
            <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600 mb-4">
              세션 연결 중
            </h1>
            <p className="text-lg font-bold text-gray-600 mb-6">
              교사 세션 정보를 불러오고 있습니다.
            </p>
            <MessageBanner message={errorMessage} />
            <button
              onClick={goHome}
              className="w-full bg-gray-400 hover:bg-gray-500 text-white py-3 px-6 rounded-xl font-bold transition-all"
            >
              처음 화면으로
            </button>
          </div>
        </div>
      );
    }

    if (sessionData.phase === 'results') {
      return (
        <ResultsScreen
          getTeamName={(teamNumber) => getTeamLabel(sessionTeamNames, teamNumber)}
          message={errorMessage}
          onPrimaryAction={() => handleTeacherAction('restart')}
          onSecondaryAction={goHome}
          primaryLabel="같은 코드로 다시 시작"
          problems={problems}
          scores={sessionData.scores}
          secondaryLabel="처음 화면으로"
        />
      );
    }

    if (sessionData.phase === 'animation') {
      return (
        <NeuralSignalAnimation
          allowNext
          footerMessage={
            currentQuestion === TOTAL_QUESTIONS - 1
              ? '마지막 애니메이션입니다. 확인 후 최종 결과를 열 수 있습니다.'
              : '애니메이션을 확인한 뒤 다음 문제를 열 수 있습니다.'
          }
          onNext={() =>
            handleTeacherAction(currentQuestion === TOTAL_QUESTIONS - 1 ? 'showResults' : 'nextQuestion')
          }
          problem={currentProblem}
        />
      );
    }

    return (
      <>
        <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-400 to-pink-400 p-4 py-6">
          <div className="max-w-7xl mx-auto space-y-6">
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <div className="flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
                <div className="xl:max-w-[38rem]">
                  <p className="text-sm font-black text-orange-500 mb-2">교사 진행 화면</p>
                  <h1 className="text-4xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">
                    신경 신호 연결 미션
                  </h1>
                  <p className="text-gray-600 font-bold text-lg mt-2">
                    교사가 문제를 열고, 학생은 같은 코드로 들어와 함께 풉니다.
                  </p>
                </div>

                <div className="grid grid-cols-1 xl:grid-cols-[1fr_1.1fr] gap-4 xl:min-w-[760px]">
                  <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-4">
                    <p className="text-sm font-black text-blue-700 mb-2">학생 참여 링크</p>
                    <input
                      readOnly
                      value={shareUrl}
                      className="w-full bg-white border-2 border-blue-200 rounded-lg px-3 py-2 text-sm font-bold text-gray-700"
                    />
                    <p className="text-xs font-bold text-gray-500 mt-2">
                      링크 접속이 어렵다면 아래 큰 세션 코드를 학생들에게 직접 보여주세요.
                    </p>
                  </div>

                  <div className="bg-gradient-to-br from-yellow-100 via-amber-50 to-orange-100 border-2 border-yellow-300 rounded-2xl p-4 shadow-sm">
                    <div className="flex items-center justify-between gap-3 mb-3">
                      <p className="text-sm font-black text-orange-700">발표용 세션 코드</p>
                      <button
                        onClick={() => setShowCodeBoard(true)}
                        className="bg-slate-900 text-yellow-300 px-3 py-2 rounded-xl text-xs font-black hover:bg-slate-800 transition-all"
                      >
                        전체 화면으로 보기
                      </button>
                    </div>
                    <div className="rounded-2xl bg-slate-900 border-2 border-yellow-300 px-4 py-5 text-center shadow-inner">
                      <p className="text-yellow-300 text-4xl md:text-6xl font-black tracking-[0.55em] pl-[0.55em] leading-none">
                        {sessionCode}
                      </p>
                    </div>
                    <p className="text-sm font-bold text-gray-600 mt-3">
                      뒷자리 학생도 볼 수 있게 크게 띄우고, 필요하면 버튼으로 더 크게 확대할 수 있습니다.
                    </p>
                  </div>
                </div>
              </div>
              <MessageBanner message={errorMessage} />
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-[1.2fr_0.8fr] gap-6">
              <div className="bg-white rounded-2xl shadow-lg p-6">
                <div className="flex justify-between items-center flex-wrap gap-4 mb-4">
                  <div>
                    <p className="text-sm font-black text-purple-500 mb-2">
                      {sessionData.phase === 'lobby'
                        ? '대기실'
                        : sessionData.phase === 'mission'
                        ? '문제 풀이 중'
                        : '애니메이션 공개 중'}
                    </p>
                    <h2 className="text-4xl font-black text-gray-800">
                      {sessionData.phase === 'lobby'
                        ? '학생 입장 대기'
                        : `문제 ${currentQuestion + 1} / ${TOTAL_QUESTIONS}`}
                    </h2>
                    <p className="text-gray-600 font-bold text-lg mt-2">
                      {currentProblem?.title || '첫 문제를 준비 중입니다.'}
                    </p>
                  </div>
                  <div
                    className={`text-5xl font-black p-6 rounded-xl ${
                      sessionData.phase !== 'mission'
                        ? 'bg-gray-100 text-gray-500'
                        : timeLeft > 30
                        ? 'bg-blue-100 text-blue-600'
                        : timeLeft > 0
                        ? 'bg-yellow-100 text-yellow-600'
                        : 'bg-red-100 text-red-600'
                    }`}
                  >
                    {sessionData.phase === 'mission' ? (
                      <>
                        ⏱️
                        <br />
                        {timeLeft}초
                      </>
                    ) : (
                      '대기'
                    )}
                  </div>
                </div>

              {sessionData.phase !== 'lobby' && currentProblem && (
                <>
                  <p className="text-center text-gray-700 font-bold mb-2">{currentProblem.description}</p>
                  <p className="text-5xl text-center mb-6">{currentProblem.emoji}</p>
                </>
              )}

              <div className="bg-gradient-to-r from-blue-50 to-purple-50 border-2 border-blue-200 rounded-2xl p-5 mb-6">
                <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
                  <p className="text-lg font-black text-blue-700">
                    제출 현황: {answeredCount} / {TEAM_COUNT} 모둠
                  </p>
                  <p className="text-sm font-bold text-gray-600">
                    현재 학생들은 교사 화면 전환에 맞춰 자동으로 이동합니다.
                  </p>
                </div>

                {sessionData.phase === 'lobby' && (
                  <button
                    onClick={() => handleTeacherAction('startGame')}
                    disabled={isBusy}
                    className="w-full bg-gradient-to-r from-green-500 to-emerald-500 disabled:opacity-50 text-white font-black py-4 px-6 rounded-xl hover:shadow-lg transition-all text-lg"
                  >
                    1번 문제 시작
                  </button>
                )}

                {sessionData.phase === 'mission' && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <button
                      onClick={() => handleTeacherAction('showAnimation')}
                      disabled={isBusy}
                      className="bg-gradient-to-r from-orange-500 to-red-500 disabled:opacity-50 text-white font-black py-4 px-6 rounded-xl hover:shadow-lg transition-all text-lg"
                    >
                      정답·애니메이션 공개
                    </button>
                    <button
                      onClick={() =>
                        handleTeacherAction(
                          currentQuestion === TOTAL_QUESTIONS - 1 ? 'showResults' : 'nextQuestion',
                        )
                      }
                      disabled={isBusy}
                      className="bg-gradient-to-r from-green-500 to-emerald-500 disabled:opacity-50 text-white font-black py-4 px-6 rounded-xl hover:shadow-lg transition-all text-lg"
                    >
                      {currentQuestion === TOTAL_QUESTIONS - 1 ? '최종 결과 보기' : '다음 문제 바로 열기'}
                    </button>
                  </div>
                )}

                {sessionData.phase === 'animation' && (
                  <button
                    onClick={() =>
                      handleTeacherAction(
                        currentQuestion === TOTAL_QUESTIONS - 1 ? 'showResults' : 'nextQuestion',
                      )
                    }
                    disabled={isBusy}
                    className="w-full bg-gradient-to-r from-green-500 to-emerald-500 disabled:opacity-50 text-white font-black py-4 px-6 rounded-xl hover:shadow-lg transition-all text-lg"
                  >
                    {currentQuestion === TOTAL_QUESTIONS - 1 ? '최종 결과 보기' : '다음 문제 열기'}
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
                {leaderboard.map((team, rankIndex) => (
                  <div
                    key={team.number}
                    className={`rounded-2xl p-5 text-center border-4 transition-all ${
                      rankIndex === 0
                        ? 'bg-gradient-to-br from-yellow-100 to-amber-100 border-yellow-400'
                        : rankIndex === 1
                        ? 'bg-gradient-to-br from-gray-100 to-slate-100 border-gray-400'
                        : rankIndex === 2
                        ? 'bg-gradient-to-br from-orange-100 to-yellow-100 border-orange-300'
                        : 'bg-white border-blue-300'
                    }`}
                  >
                    <div className="text-5xl font-black mb-3">
                      {rankIndex === 0 ? '🥇' : rankIndex === 1 ? '🥈' : rankIndex === 2 ? '🥉' : '⭐'}
                    </div>
                    <p className="text-2xl font-black text-gray-800 mb-2">
                      {getTeamLabel(sessionTeamNames, team.number)}
                    </p>
                    <div
                      className={`text-4xl font-black mb-3 ${
                        team.answer
                          ? team.currentScore > 0
                            ? 'text-green-600'
                            : 'text-orange-600'
                          : 'text-gray-500'
                      }`}
                    >
                      {team.answer ? `${team.currentScore}점` : '...'}
                    </div>
                    <p
                      className={`font-bold text-lg ${
                        team.answer
                          ? team.currentScore > 0
                            ? 'text-green-600'
                            : 'text-orange-600'
                          : 'text-gray-500'
                      }`}
                    >
                      {team.answer ? '제출 완료' : '미제출'}
                    </p>
                    <p className="text-sm text-gray-600 font-bold mt-3">누적: {team.total}점</p>
                    {team.answer && (
                      <div className="mt-4 bg-white/80 rounded-lg p-3 text-left text-xs font-bold text-gray-700 leading-relaxed">
                        {team.answer.sequence.map((card) => card.text).join(' → ')}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h3 className="text-2xl font-black text-gray-800 mb-4">교사용 메모</h3>
              <div className="space-y-4 text-sm font-bold text-gray-700 leading-relaxed">
                <p>1. 학생은 세션 코드로 입장하고, 같은 문제 화면을 자동으로 공유합니다.</p>
                <p>2. 학생이 제출하면 이 화면에서 바로 제출 여부와 경로를 확인할 수 있습니다.</p>
                <p>3. 교사가 애니메이션 공개 또는 다음 문제 열기를 누를 때 전체 학생 화면이 함께 이동합니다.</p>
                <p>4. 마지막 문제에서는 “최종 결과 보기”를 누르면 전체 결과 화면으로 전환됩니다.</p>
              </div>
              <button
                onClick={goHome}
                className="w-full mt-6 bg-gray-400 hover:bg-gray-500 text-white py-3 px-6 rounded-xl font-bold transition-all"
              >
                세션 종료하고 처음으로
              </button>
            </div>
          </div>
        </div>
        </div>

        {showCodeBoard && (
          <SessionCodeOverlay onClose={() => setShowCodeBoard(false)} sessionCode={sessionCode} />
        )}
      </>
    );
  }
  if (role === 'student' && sessionCode && sessionData) {
    if (selectedStudentTeam === null) {
      return (
        <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-400 to-pink-400 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl p-8 max-w-3xl w-full">
            <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600 mb-4 text-center">
              신경 신호 연결 미션
            </h1>
            <p className="text-center text-gray-600 font-bold text-lg mb-8">
              세션 `{sessionCode}`에 입장했습니다. 자신의 모둠을 선택하세요.
            </p>
            <MessageBanner message={errorMessage} />
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              {buildTeamNumbers().map((teamNumber) => (
                <button
                  key={teamNumber}
                  onClick={() => setSelectedStudentTeam(teamNumber)}
                  className="p-6 rounded-2xl font-black text-lg bg-gradient-to-r from-blue-500 to-purple-500 text-white hover:shadow-lg hover:scale-105 transition-all"
                >
                  {getTeamLabel(sessionTeamNames, teamNumber)}
                </button>
              ))}
            </div>
            <button
              onClick={goHome}
              className="w-full bg-gray-400 hover:bg-gray-500 text-white py-3 px-6 rounded-xl font-bold transition-all"
            >
              세션 나가기
            </button>
          </div>
        </div>
      );
    }

    if (sessionData.phase === 'results') {
      return (
        <ResultsScreen
          getTeamName={(teamNumber) => getTeamLabel(sessionTeamNames, teamNumber)}
          message={errorMessage}
          onPrimaryAction={goHome}
          primaryLabel="세션 나가기"
          problems={problems}
          scores={sessionData.scores}
        />
      );
    }

    if (sessionData.phase === 'lobby') {
      return (
        <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-400 to-pink-400 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl p-10 max-w-2xl w-full text-center">
            <p className="text-sm font-black text-purple-500 mb-3">학생 대기 화면</p>
            <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600 mb-4">
              {getTeamLabel(sessionTeamNames, selectedStudentTeam)}
            </h1>
            <p className="text-lg font-bold text-gray-600 mb-6">
              교사가 첫 문제를 열면 자동으로 문제 화면으로 이동합니다.
            </p>
            <MessageBanner message={errorMessage} />
            <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-6">
              <p className="text-2xl font-black text-blue-700 mb-2">세션 코드 {sessionCode}</p>
              <p className="text-sm font-bold text-gray-600">현재는 모든 학생이 입장하는 중입니다.</p>
            </div>
            <button
              onClick={goHome}
              className="w-full mt-6 bg-gray-400 hover:bg-gray-500 text-white py-3 px-6 rounded-xl font-bold transition-all"
            >
              세션 나가기
            </button>
          </div>
        </div>
      );
    }

    if (sessionData.phase === 'animation') {
      return (
        <NeuralSignalAnimation
          footerMessage="교사가 다음 문제를 열면 자동으로 이동합니다."
          problem={currentProblem}
          showAdvanceButton={false}
        />
      );
    }

    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-400 to-pink-400 p-4 py-6">
        <div className="max-w-3xl mx-auto">
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-6">
            <div className="flex justify-between items-center flex-wrap gap-4">
              <div>
                <p className="text-sm font-black text-blue-500 mb-2">학생 문제 풀이</p>
                <h2 className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">
                  {getTeamLabel(sessionTeamNames, selectedStudentTeam)}
                </h2>
                <p className="text-gray-600 font-bold">문제 {currentQuestion + 1} / {TOTAL_QUESTIONS}</p>
              </div>
              <div
                className={`text-4xl font-black p-4 rounded-xl ${
                  timeLeft > 30
                    ? 'bg-blue-100 text-blue-600'
                    : timeLeft > 0
                    ? 'bg-yellow-100 text-yellow-600'
                    : 'bg-red-100 text-red-600'
                }`}
              >
                ⏱️ {timeLeft}초
              </div>
            </div>
            <p className="text-lg font-bold text-gray-700 mt-4 mb-2">{currentProblem.description}</p>
            <p className="text-5xl text-center">{currentProblem.emoji}</p>
            <MessageBanner message={errorMessage} />
          </div>

          <CardMissionComponent
            key={`${selectedStudentTeam}-${currentQuestion}`}
            isLocked={isBusy}
            onSubmit={handleSubmitAnswer}
            problem={currentProblem}
            submittedAnswer={selectedTeamAnswer}
          />

          {selectedTeamAnswer && (
            <div className="mt-6 bg-blue-50 border-2 border-blue-200 rounded-2xl p-5">
              <p className="text-lg font-black text-blue-700 mb-2">제출 완료</p>
              <p className="text-sm font-bold text-gray-700">
                교사가 애니메이션을 공개하거나 다음 문제를 열면 자동으로 화면이 전환됩니다.
              </p>
            </div>
          )}

          {!selectedTeamAnswer && timeLeft === 0 && (
            <div className="mt-6 bg-yellow-50 border-2 border-yellow-300 rounded-2xl p-5">
              <p className="text-sm font-bold text-yellow-800">
                시간 보너스는 종료됐지만 제출은 계속할 수 있습니다.
              </p>
            </div>
          )}

          <button
            onClick={goHome}
            className="w-full mt-6 bg-gray-400 hover:bg-gray-500 text-white py-3 px-6 rounded-xl font-bold transition-all"
          >
            세션 나가기
          </button>
        </div>
      </div>
    );
  }

  if (screen === 'home') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-400 to-pink-400 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl shadow-2xl p-10 max-w-4xl w-full">
          <h1 className="text-5xl md:text-6xl font-black text-center text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600 mb-4">
            신경 신호 연결 미션
          </h1>
          <p className="text-center text-gray-600 font-bold mb-10 text-lg">
            교사가 세션을 열면 학생들이 같은 문제를 함께 풀고, 제출 현황도 실시간으로 확인할 수 있습니다.
          </p>
          <MessageBanner message={errorMessage} />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <button
              onClick={() => {
                setRole('teacher');
                setScreen('setup');
                setErrorMessage('');
              }}
              className="bg-gradient-to-br from-orange-400 to-red-500 hover:shadow-2xl hover:scale-105 transition-all rounded-2xl p-12 text-white text-left"
            >
              <div className="text-6xl mb-4">👨‍🏫</div>
              <h2 className="text-3xl font-black mb-2">교사 세션 만들기</h2>
              <p className="text-sm font-bold">문제 시작, 애니메이션 공개, 다음 문제 진행을 교사가 제어합니다.</p>
            </button>
            <button
              onClick={() => {
                setRole('student');
                setScreen('studentJoin');
                setErrorMessage('');
              }}
              className="bg-gradient-to-br from-blue-400 to-cyan-500 hover:shadow-2xl hover:scale-105 transition-all rounded-2xl p-12 text-white text-left"
            >
              <div className="text-6xl mb-4">👨‍🎓</div>
              <h2 className="text-3xl font-black mb-2">학생 세션 참여</h2>
              <p className="text-sm font-bold">세션 코드로 입장한 뒤 같은 문제를 함께 풀고 자동으로 다음 문제로 이동합니다.</p>
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (screen === 'setup') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-400 to-pink-400 p-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-3xl shadow-2xl p-8">
            <h1 className="text-5xl md:text-6xl font-black text-center text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600 mb-4">
              신경 신호 연결 미션
            </h1>
            <p className="text-center text-gray-600 font-bold mb-8 text-lg">
              교사 활동 유형을 선택하세요
            </p>
            <MessageBanner message={errorMessage} />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <button
                onClick={() => {
                  setActivityTab('conscious');
                  setScreen('teamSetup');
                }}
                className="bg-gradient-to-br from-blue-400 to-cyan-500 hover:shadow-2xl hover:scale-105 transition-all rounded-2xl p-12 text-white"
              >
                <div className="text-6xl mb-4">🧠</div>
                <h2 className="text-3xl font-black mb-2">의식적 반응</h2>
                <p className="text-sm font-bold">대뇌에서 판단하고 의도적으로 행동</p>
              </button>

              <button
                onClick={() => {
                  setActivityTab('unconditional');
                  setScreen('teamSetup');
                }}
                className="bg-gradient-to-br from-orange-400 to-red-500 hover:shadow-2xl hover:scale-105 transition-all rounded-2xl p-12 text-white"
              >
                <div className="text-6xl mb-4">⚡</div>
                <h2 className="text-3xl font-black mb-2">무조건 반사</h2>
                <p className="text-sm font-bold">뇌를 거치지 않고 자동으로 반응</p>
              </button>
            </div>

            <button
              onClick={goHome}
              className="w-full bg-gray-400 hover:bg-gray-500 text-white py-3 px-6 rounded-xl font-bold transition-all"
            >
              처음 화면으로
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (screen === 'teamSetup') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-400 to-pink-400 p-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-3xl shadow-2xl p-8">
            <h1 className="text-4xl font-black text-center text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600 mb-2">
              신경 신호 연결 미션
            </h1>
            <p className="text-center text-gray-600 font-bold mb-8 text-lg">
              8개 모둠 이름을 입력하고 세션을 만드세요
            </p>
            <MessageBanner message={errorMessage} />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
              {buildTeamNumbers().map((teamNumber) => (
                <div key={teamNumber}>
                  <label className="block text-sm font-bold text-gray-700 mb-2">모둠 {teamNumber}</label>
                  <input
                    type="text"
                    value={teamNames[teamNumber] || ''}
                    onChange={(event) => {
                      setTeamNames((prev) => ({
                        ...prev,
                        [teamNumber]: event.target.value,
                      }));
                    }}
                    placeholder={getDefaultTeamName(teamNumber)}
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none font-bold"
                  />
                </div>
              ))}
            </div>

            <div className="flex gap-4">
              <button
                onClick={handleCreateSession}
                disabled={isBusy}
                className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500 disabled:opacity-50 hover:shadow-lg text-white py-4 px-6 rounded-xl font-black text-xl transition-all"
              >
                세션 만들기
              </button>
              <button
                onClick={() => setScreen('setup')}
                className="flex-1 bg-gray-400 hover:bg-gray-500 text-white py-4 px-6 rounded-xl font-black text-xl transition-all"
              >
                ← 돌아가기
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (screen === 'studentJoin') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-400 to-pink-400 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl shadow-2xl p-10 max-w-2xl w-full">
          <h1 className="text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600 mb-4 text-center">
            학생 세션 참여
          </h1>
          <p className="text-center text-gray-600 font-bold mb-8 text-lg">
            교사가 알려준 세션 코드를 입력하면 같은 문제 화면으로 연결됩니다.
          </p>
          <MessageBanner message={errorMessage} />
          <div className="mb-6">
            <label className="block text-sm font-bold text-gray-700 mb-2">세션 코드</label>
            <input
              type="text"
              value={sessionCodeInput}
              onChange={(event) => setSessionCodeInput(normalizeSessionCode(event.target.value))}
              placeholder="예: A7K2Q9"
              className="w-full px-4 py-4 border-2 border-gray-300 rounded-xl focus:border-blue-500 focus:outline-none font-black text-center tracking-[0.4em] text-2xl"
              maxLength={6}
            />
          </div>
          <div className="flex gap-4">
            <button
              onClick={handleJoinSession}
              disabled={isBusy}
              className="flex-1 bg-gradient-to-r from-blue-500 to-purple-500 disabled:opacity-50 text-white py-4 px-6 rounded-xl font-black text-xl hover:shadow-lg transition-all"
            >
              세션 입장
            </button>
            <button
              onClick={goHome}
              className="flex-1 bg-gray-400 hover:bg-gray-500 text-white py-4 px-6 rounded-xl font-black text-xl transition-all"
            >
              처음 화면으로
            </button>
          </div>
        </div>
      </div>
    );
  }

  return null;
}
function MessageBanner({ message }) {
  if (!message) {
    return null;
  }

  return (
    <div className="bg-red-50 border-2 border-red-200 rounded-xl p-4 text-sm font-bold text-red-700 mb-6">
      {message}
    </div>
  );
}

function SessionCodeOverlay({ onClose, sessionCode }) {
  return (
    <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-sm p-4 flex items-center justify-center">
      <div className="w-full max-w-6xl bg-white rounded-[2rem] shadow-2xl border-4 border-yellow-300 p-6 md:p-10 text-center">
        <p className="text-lg md:text-2xl font-black text-orange-500 mb-3">학생 참여용 세션 코드</p>
        <h2 className="text-3xl md:text-5xl font-black text-gray-800 mb-6">
          교실 뒤쪽에서도 보이도록 크게 표시했습니다
        </h2>
        <div className="rounded-[2rem] bg-slate-900 px-6 py-8 md:px-10 md:py-12 border-4 border-yellow-300 shadow-inner mb-6">
          <p className="text-yellow-300 font-black tracking-[0.9em] pl-[0.9em] text-5xl md:text-8xl lg:text-[9rem] leading-none">
            {sessionCode}
          </p>
        </div>
        <p className="text-base md:text-xl font-bold text-gray-600 mb-6">
          학생들은 첫 화면에서 이 코드를 입력해 같은 문제 화면으로 입장합니다.
        </p>
        <button
          onClick={onClose}
          className="bg-gradient-to-r from-blue-500 to-purple-500 text-white font-black py-4 px-8 rounded-2xl text-lg md:text-2xl hover:shadow-lg transition-all"
        >
          코드 크게 보기 닫기
        </button>
      </div>
    </div>
  );
}

function ResultsScreen({
  getTeamName,
  message,
  onPrimaryAction,
  onSecondaryAction,
  primaryLabel,
  problems,
  scores,
  secondaryLabel,
}) {
  const sorted = buildTeamNumbers()
    .map((teamNumber) => {
      const teamScores = scores?.[String(teamNumber)] || Array(TOTAL_QUESTIONS).fill(0);
      return {
        number: teamNumber,
        perQuestion: teamScores,
        total: teamScores.reduce((sum, score) => sum + score, 0),
      };
    })
    .sort((left, right) => right.total - left.total);

  const [first, second, third, ...rest] = sorted;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-400 to-pink-400 p-4 py-8">
      <div className="max-w-6xl mx-auto">
        <div className="bg-white rounded-3xl shadow-2xl p-8">
          <h2 className="text-5xl font-black text-center mb-2 text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">
            🏆 최종 순위 🏆
          </h2>
          <p className="text-center text-gray-600 font-bold mb-12 text-lg">6문제 · 만점 60점</p>
          <MessageBanner message={message} />

          <div className="mb-12">
            <div className="flex justify-center">
              <div className="text-center">
                <div className="bg-gradient-to-b from-yellow-200 to-yellow-100 rounded-3xl shadow-2xl p-8 border-4 border-yellow-400 w-64 mx-auto mb-4">
                  <div className="text-8xl font-black mb-4">🥇</div>
                  <p className="text-4xl font-black text-gray-800 mb-2">{getTeamName(first.number)}</p>
                  <p className="text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-500 to-amber-600 mb-4">
                    {first.total}점
                  </p>
                  <div className="grid grid-cols-6 gap-1">
                    {problems.map((_, questionIndex) => (
                      <div key={questionIndex} className="bg-white rounded p-1 text-center">
                        <p className="text-xs text-gray-600 font-bold">Q{questionIndex + 1}</p>
                        <p className="text-sm font-black text-gray-800">{first.perQuestion[questionIndex] || 0}</p>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="bg-yellow-400 w-64 h-16 rounded-b-lg shadow-lg flex items-center justify-center">
                  <p className="text-3xl font-black text-white">🏆 1등 🏆</p>
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-center gap-8 mb-12 flex-wrap">
            {[second, third].filter(Boolean).map((team, index) => (
              <div key={team.number} className="text-center">
                <div
                  className={`rounded-3xl shadow-xl p-6 border-4 w-56 mx-auto mb-4 ${
                    index === 0
                      ? 'bg-gradient-to-b from-gray-300 to-gray-100 border-gray-400'
                      : 'bg-gradient-to-b from-orange-200 to-orange-100 border-orange-400'
                  }`}
                >
                  <div className="text-7xl font-black mb-3">{index === 0 ? '🥈' : '🥉'}</div>
                  <p className="text-3xl font-black text-gray-800 mb-2">{getTeamName(team.number)}</p>
                  <p
                    className={`text-5xl font-black mb-3 ${
                      index === 0 ? 'text-gray-600' : 'text-orange-600'
                    }`}
                  >
                    {team.total}점
                  </p>
                  <div className="grid grid-cols-6 gap-1">
                    {problems.map((_, questionIndex) => (
                      <div key={questionIndex} className="bg-white rounded p-1 text-center">
                        <p className="text-xs text-gray-600 font-bold">Q{questionIndex + 1}</p>
                        <p className="text-sm font-black text-gray-800">{team.perQuestion[questionIndex] || 0}</p>
                      </div>
                    ))}
                  </div>
                </div>
                <div
                  className={`w-56 rounded-b-lg shadow-lg flex items-center justify-center ${
                    index === 0 ? 'bg-gray-400 h-12' : 'bg-orange-400 h-8'
                  }`}
                >
                  <p className="text-2xl font-black text-white">{index + 2}등</p>
                </div>
              </div>
            ))}
          </div>

          {rest.length > 0 && (
            <div className="mb-8">
              <h3 className="text-3xl font-black text-gray-800 mb-6 text-center">⭐ 4등 이하</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {rest.map((team, index) => (
                  <div key={team.number} className="bg-white rounded-2xl p-6 border-2 border-blue-300 shadow-lg">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-4">
                        <div className="text-4xl font-black">⭐</div>
                        <p className="text-2xl font-black text-gray-800">
                          {index + 4}등: {getTeamName(team.number)}
                        </p>
                      </div>
                      <p className="text-4xl font-black text-blue-600">{team.total}점</p>
                    </div>
                    <div className="grid grid-cols-6 gap-1">
                      {problems.map((_, questionIndex) => (
                        <div key={questionIndex} className="bg-gray-100 rounded p-1 text-center">
                          <p className="text-xs text-gray-600 font-bold">Q{questionIndex + 1}</p>
                          <p className="text-sm font-black text-gray-800">{team.perQuestion[questionIndex] || 0}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="flex flex-col gap-4">
            {onPrimaryAction && (
              <button
                onClick={onPrimaryAction}
                className="w-full bg-gradient-to-r from-blue-500 to-purple-500 text-white py-4 px-6 rounded-xl font-black text-lg hover:shadow-lg transition-all"
              >
                {primaryLabel}
              </button>
            )}
            {onSecondaryAction && (
              <button
                onClick={onSecondaryAction}
                className="w-full bg-gray-400 hover:bg-gray-500 text-white py-4 px-6 rounded-xl font-black text-lg transition-all"
              >
                {secondaryLabel}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
// ===== 카드 미션 컴포넌트 =====
function CardMissionComponent({ isLocked, onSubmit, problem, submittedAnswer }) {
  const [sequence, setSequence] = useState([]);
  const [availableCards, setAvailableCards] = useState([]);
  const [problemCardMap, setProblemCardMap] = useState({});

  useEffect(() => {
    const existingCards = problemCardMap[problem.id];

    if (existingCards) {
      setAvailableCards(existingCards);
      setSequence([]);
      return;
    }

    const shuffled = [...problem.allCards];
    for (let index = shuffled.length - 1; index > 0; index -= 1) {
      const swapIndex = Math.floor(Math.random() * (index + 1));
      [shuffled[index], shuffled[swapIndex]] = [shuffled[swapIndex], shuffled[index]];
    }

    setProblemCardMap((prev) => ({
      ...prev,
      [problem.id]: shuffled,
    }));
    setAvailableCards(shuffled);
    setSequence([]);
  }, [problem.id, problemCardMap]);

  const addCard = (card) => {
    if (sequence.length < 7 && !sequence.find((selectedCard) => selectedCard.id === card.id)) {
      setSequence([...sequence, card]);
    }
  };

  const removeCard = (index) => {
    setSequence(sequence.filter((_, sequenceIndex) => sequenceIndex !== index));
  };

  if (submittedAnswer) {
    return (
      <div
        className={`rounded-2xl shadow-lg p-6 border-3 ${
          submittedAnswer.isCorrect
            ? 'bg-gradient-to-br from-green-100 to-emerald-100 border-green-400'
            : 'bg-gradient-to-br from-yellow-100 to-orange-100 border-yellow-400'
        }`}
      >
        <div
          className={`text-4xl font-black mb-4 text-center ${
            submittedAnswer.isCorrect ? 'text-green-600' : 'text-yellow-600'
          }`}
        >
          {submittedAnswer.isCorrect ? '🎉 정답!' : '⚠️ 오답'}
        </div>

        <div className="mt-6 space-y-3">
          <div>
            <p className="text-sm font-bold text-gray-700 mb-2">우리 모둠 제출:</p>
            <div className="bg-white rounded-lg p-3 text-sm font-bold text-gray-800">
              {submittedAnswer.sequence.map((card) => card.text).join(' → ') || '답변 없음'}
            </div>
          </div>
          <div>
            <p className="text-sm font-bold text-gray-700 mb-2">정답:</p>
            <div className="bg-white rounded-lg p-3 text-sm font-bold text-green-700">
              {problem.correctSequence.join(' → ')}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-lg p-6 border-3 border-blue-300">
      <div className="mb-4">
        <p className="text-sm font-bold text-gray-700 mb-2">📌 카드 선택</p>
        <div className="grid grid-cols-2 gap-2 max-h-40 overflow-y-auto bg-gray-50 p-2 rounded-lg">
          {availableCards.map((card) => {
            const isUsed = sequence.some((selectedCard) => selectedCard.id === card.id);
            return (
              <button
                key={card.id}
                onClick={() => addCard(card)}
                disabled={isUsed}
                className={`p-2 rounded text-xs font-bold transition-all ${
                  isUsed
                    ? 'bg-gray-300 text-gray-500 opacity-50 line-through'
                    : 'bg-blue-200 text-blue-900 hover:bg-blue-300 border-2 border-blue-400'
                }`}
              >
                {card.text}
              </button>
            );
          })}
        </div>
      </div>

      <div className="mb-4">
        <p className="text-sm font-bold text-gray-700 mb-2">🔗 신경 신호 경로</p>
        <div className="space-y-2">
          {Array.from({ length: 7 }).map((_, index) => (
            <div key={index} className="flex items-center gap-2">
              <div className="text-xs font-black text-gray-400 w-5">{index + 1}</div>
              <div
                onClick={() => {
                  if (sequence[index]) {
                    removeCard(index);
                  }
                }}
                className="flex-1 bg-gradient-to-r from-blue-100 to-purple-100 border-2 border-dashed border-blue-300 rounded p-2 min-h-10 flex items-center text-xs font-bold text-gray-700 cursor-pointer hover:shadow-md transition-all"
              >
                {sequence[index] ? sequence[index].text : '빈 칸'}
              </div>
              {index < 6 && <div className="text-lg text-blue-400">→</div>}
            </div>
          ))}
        </div>
      </div>

      <button
        onClick={() => onSubmit(sequence)}
        disabled={isLocked || sequence.length === 0}
        className="w-full bg-gradient-to-r from-green-500 to-emerald-500 hover:shadow-lg disabled:opacity-50 text-white py-3 px-4 rounded-lg font-black transition-all"
      >
        {isLocked ? '전송 중...' : '✓ 제출'}
      </button>
    </div>
  );
}

// ===== 신경신호 애니메이션 =====
const SIGNAL_STAGE_LABELS = ['자극', '감지', '입력 전달', '중추 처리', '출력 전달', '반응 기관', '몸의 반응'];

function getSignalStageLabel(index) {
  return SIGNAL_STAGE_LABELS[index] || `단계 ${index + 1}`;
}

function interpolatePoint(start, end, ratio) {
  return {
    x: start.x + (end.x - start.x) * ratio,
    y: start.y + (end.y - start.y) * ratio,
  };
}

function getMotionType(problem) {
  const finalLabel = problem.animationSteps[problem.animationSteps.length - 1]?.label || '';

  if (finalLabel.includes('달리기')) return 'run';
  if (finalLabel.includes('답 쓰기')) return 'write';
  if (finalLabel.includes('감사말')) return 'speak';
  if (finalLabel.includes('아이템 구매')) return 'tap';
  if (finalLabel.includes('버스 탑승')) return 'step';
  if (finalLabel.includes('손 들기')) return 'raise-hand';
  if (finalLabel.includes('다리 펴짐')) return 'kick';
  if (finalLabel.includes('손 떼기')) return 'withdraw';
  if (finalLabel.includes('재채기')) return 'sneeze';
  if (finalLabel.includes('기침')) return 'cough';
  if (finalLabel.includes('눈 깜빡임')) return 'blink';
  if (finalLabel.includes('동공 축소')) return 'pupil';
  return 'neutral';
}

function getSignalModeSummary(problem) {
  return problem.type === 'unconditional'
    ? '무조건 반사는 대뇌를 거치지 않고 더 빠르게 일어나 몸을 보호합니다.'
    : '의식적 반응은 대뇌에서 판단한 뒤 목적에 맞는 움직임을 만들어 냅니다.';
}

function getSignalPhaseText(problem, animationStep, currentStep) {
  if (animationStep === 0) {
    return `${currentStep.label} 자극이 몸에 들어오고 있습니다.`;
  }

  if (animationStep === 1) {
    return `${currentStep.label}이(가) 자극을 감지해 신호를 만들기 시작합니다.`;
  }

  if (animationStep === 2) {
    return '입력된 정보가 감각 신경을 따라 중추 신경계 쪽으로 이동합니다.';
  }

  if (animationStep === 3) {
    return problem.type === 'unconditional'
      ? '척수나 뇌간이 즉시 반사 명령을 정리해 빠른 보호 반응을 준비합니다.'
      : '대뇌가 자극의 의미를 해석하고 어떤 행동을 할지 판단합니다.';
  }

  if (animationStep === 4) {
    return '중추에서 정리한 명령이 운동 신경을 따라 반응 기관으로 전달됩니다.';
  }

  if (animationStep === 5) {
    return `${currentStep.label}이(가) 명령을 받아 실제 움직일 준비를 마쳤습니다.`;
  }

  return `${currentStep.label} 반응이 몸 밖으로 실제로 나타나는 순간입니다.`;
}

function getBodyResponseSummary(problem) {
  const motionType = getMotionType(problem);

  switch (motionType) {
    case 'run':
      return '다리 근육이 번갈아 수축하며 몸이 앞으로 달려 나갑니다.';
    case 'write':
      return '손목과 손가락이 세밀하게 움직이며 답을 쓰는 동작이 나타납니다.';
    case 'speak':
      return '입 주변 근육이 움직이며 감사의 말이 소리로 표현됩니다.';
    case 'tap':
      return '손가락이 빠르게 눌리며 필요한 아이템을 선택하는 동작이 일어납니다.';
    case 'step':
      return '다리 근육이 수축하면서 발을 앞으로 내딛고 버스에 탑승합니다.';
    case 'raise-hand':
      return '팔 근육이 수축하며 팔이 위로 올라가고 손이 들립니다.';
    case 'kick':
      return '무릎 아래 다리가 반사적으로 앞으로 튀어 오르듯 펴집니다.';
    case 'withdraw':
      return '뜨거운 자극을 피하려고 손이 즉시 뒤로 물러납니다.';
    case 'sneeze':
      return '호흡 근육이 강하게 수축하며 공기가 밖으로 터져 나가 재채기가 일어납니다.';
    case 'cough':
      return '호흡 근육이 수축해 기도로 들어온 이물질을 밀어내듯 기침이 나옵니다.';
    case 'blink':
      return '눈꺼풀 근육이 빠르게 닫혔다 열리며 눈을 보호합니다.';
    case 'pupil':
      return '홍채 근육이 수축해 동공이 작아지며 눈으로 들어오는 빛을 줄입니다.';
    default:
      return '신경 신호가 전달된 뒤 몸의 반응이 실제 움직임으로 나타납니다.';
  }
}

function getSensorPoint(label) {
  if (label.includes('귀')) return { x: 211, y: 93 };
  if (label.includes('눈')) return { x: 250, y: 86 };
  if (label.includes('코')) return { x: 250, y: 100 };
  if (label.includes('목')) return { x: 250, y: 136 };
  if (label.includes('무릎')) return { x: 236, y: 288 };
  if (label.includes('손가락') || label.includes('손')) return { x: 332, y: 234 };
  return { x: 250, y: 140 };
}

function getCentralPoint(label) {
  if (label.includes('대뇌')) return { x: 250, y: 68 };
  if (label.includes('중간뇌')) return { x: 250, y: 84 };
  if (label.includes('연수')) return { x: 250, y: 118 };
  if (label.includes('척수')) return { x: 250, y: 190 };
  return { x: 250, y: 120 };
}

function getEffectorPoint(label) {
  if (label.includes('입 근육')) return { x: 250, y: 116 };
  if (label.includes('호흡 근육')) return { x: 250, y: 178 };
  if (label.includes('눈 근육')) return { x: 250, y: 86 };
  if (label.includes('손가락') || label.includes('손 근육')) return { x: 332, y: 234 };
  if (label.includes('팔 근육')) return { x: 308, y: 176 };
  if (label.includes('다리 근육')) return { x: 272, y: 296 };
  return { x: 290, y: 210 };
}

function getStimulusPoint(label, sensorPoint) {
  if (label.includes('밝은 빛')) return { x: 92, y: 64 };
  if (label.includes('물체 접근')) return { x: 90, y: 92 };
  if (label.includes('뜨거운 자극')) return { x: 92, y: 234 };
  if (label.includes('무릎 자극')) return { x: 94, y: 288 };
  if (label.includes('먼지 자극')) return { x: 100, y: 96 };
  if (label.includes('이물질 자극')) return { x: 98, y: 136 };
  if (label.includes('선물')) return { x: 96, y: 84 };
  return { x: Math.max(86, sensorPoint.x - 150), y: sensorPoint.y };
}

function getResponsePoint(finalLabel, motionType, effectorPoint) {
  switch (motionType) {
    case 'run':
    case 'step':
    case 'kick':
      return { x: 386, y: 322 };
    case 'write':
    case 'tap':
    case 'raise-hand':
    case 'withdraw':
      return { x: 392, y: 182 };
    case 'speak':
    case 'sneeze':
    case 'cough':
      return { x: 392, y: 110 };
    case 'blink':
    case 'pupil':
      return { x: 390, y: 82 };
    default:
      return { x: effectorPoint.x + 92, y: effectorPoint.y - 18 };
  }
}

function buildSignalScene(problem) {
  const steps = problem.animationSteps;
  const motionType = getMotionType(problem);
  const sensorPoint = getSensorPoint(steps[1]?.label || steps[0]?.label || '');
  const centralPoint = getCentralPoint(steps[3]?.label || steps[2]?.label || '');
  const effectorPoint = getEffectorPoint(steps[5]?.label || steps[6]?.label || '');
  const stimulusPoint = getStimulusPoint(steps[0]?.label || '', sensorPoint);
  const responsePoint = getResponsePoint(steps[6]?.label || '', motionType, effectorPoint);
  const sensoryRelayPoint = interpolatePoint(sensorPoint, centralPoint, 0.52);
  const centralDecisionPoint =
    steps[3]?.label?.includes('반사') || steps[4]?.label?.includes('반사')
      ? { x: centralPoint.x + 18, y: centralPoint.y + 18 }
      : centralPoint;
  const motorRelayPoint = interpolatePoint(centralDecisionPoint, effectorPoint, 0.58);

  return {
    motionType,
    nodes: [
      stimulusPoint,
      sensorPoint,
      steps[2]?.label?.includes('감각 신경') ? sensoryRelayPoint : centralPoint,
      centralDecisionPoint,
      steps[4]?.label?.includes('운동 신경') ? motorRelayPoint : effectorPoint,
      effectorPoint,
      responsePoint,
    ],
  };
}

function getMarkerPoint(index) {
  const markerPoints = [
    { x: 78, y: 52, side: 'left' },
    { x: 78, y: 106, side: 'left' },
    { x: 92, y: 170, side: 'left' },
    { x: 250, y: 36, side: 'center' },
    { x: 428, y: 168, side: 'right' },
    { x: 442, y: 244, side: 'right' },
    { x: 430, y: 320, side: 'right' },
  ];

  return markerPoints[index] || { x: 80 + index * 40, y: 60, side: 'left' };
}

function getPoseState(motionType, animationStep, motionBeat) {
  const beat = motionBeat === 0 ? -1 : 1;
  const isPrimed = animationStep >= 5;
  const isReacting = animationStep >= 6;
  const pose = {
    leftArm: -8,
    rightArm: 8,
    leftLeg: -2,
    rightLeg: 2,
    blink: false,
    mouthCurve: 3,
    mouthHeight: 0,
    pupilScale: 1,
    chestScale: 1,
  };

  switch (motionType) {
    case 'run':
      if (isPrimed) {
        pose.leftArm = -28 + beat * 28;
        pose.rightArm = 28 - beat * 28;
        pose.leftLeg = 10 - beat * 24;
        pose.rightLeg = -10 + beat * 24;
      }
      break;
    case 'write':
      if (isPrimed) {
        pose.leftArm = -20;
        pose.rightArm = 66 + beat * 4;
        pose.leftLeg = -4;
        pose.rightLeg = 4;
      }
      break;
    case 'speak':
      pose.leftArm = -12;
      pose.rightArm = 12;
      if (isPrimed) {
        pose.mouthCurve = 5 + Math.abs(beat) * 2;
        pose.mouthHeight = isReacting ? 6 + Math.abs(beat) * 2 : 2;
      }
      break;
    case 'tap':
      if (isPrimed) {
        pose.leftArm = -14;
        pose.rightArm = 58 + beat * 6;
      }
      break;
    case 'step':
      if (isPrimed) {
        pose.leftArm = -18 + beat * 10;
        pose.rightArm = 20 - beat * 10;
        pose.leftLeg = -8 + beat * 8;
        pose.rightLeg = 12 + beat * 18;
      }
      break;
    case 'raise-hand':
      if (isPrimed) {
        pose.leftArm = -12;
        pose.rightArm = -118 + beat * 4;
      }
      break;
    case 'kick':
      if (isPrimed) {
        pose.rightLeg = 24 + (isReacting ? beat * 12 : 4);
        pose.leftLeg = -8;
      }
      break;
    case 'withdraw':
      if (isPrimed) {
        pose.rightArm = -46 + beat * 10;
        pose.leftArm = -10;
      }
      break;
    case 'sneeze':
      if (isPrimed) {
        pose.mouthCurve = 7;
        pose.mouthHeight = isReacting ? 10 : 4;
        pose.chestScale = isReacting ? 1.08 : 1.02;
      }
      break;
    case 'cough':
      if (isPrimed) {
        pose.mouthCurve = 6;
        pose.mouthHeight = isReacting ? 8 : 3;
        pose.chestScale = isReacting ? 1.06 : 1.02;
      }
      break;
    case 'blink':
      if (isPrimed) {
        pose.blink = isReacting ? motionBeat % 2 === 0 : false;
      }
      break;
    case 'pupil':
      if (isPrimed) {
        pose.pupilScale = isReacting ? 0.45 : 0.72;
      }
      break;
    default:
      break;
  }

  return pose;
}

function LimbChain({ activeColor, anchorX, anchorY, isActive = false, length1 = 42, length2 = 36, rotation = 0 }) {
  return (
    <g transform={`translate(${anchorX} ${anchorY})`}>
      <g transform={`rotate(${rotation})`}>
        <line
          x1="0"
          y1="0"
          x2="0"
          y2={length1}
          stroke={isActive ? activeColor : '#334155'}
          strokeWidth="12"
          strokeLinecap="round"
        />
        <line
          x1="0"
          y1={length1}
          x2="0"
          y2={length1 + length2}
          stroke={isActive ? activeColor : '#475569'}
          strokeWidth="10"
          strokeLinecap="round"
        />
        <circle
          cx="0"
          cy={length1 + length2 + 7}
          r={isActive ? 7 : 6}
          fill={isActive ? activeColor : '#0f172a'}
        />
      </g>
    </g>
  );
}

function HumanSignalScene({ animationStep, problem }) {
  const scene = buildSignalScene(problem);
  const [motionBeat, setMotionBeat] = useState(0);

  useEffect(() => {
    const intervalId = window.setInterval(() => {
      setMotionBeat((prev) => (prev + 1) % 2);
    }, 420);

    return () => clearInterval(intervalId);
  }, [problem.id]);

  const pose = getPoseState(scene.motionType, animationStep, motionBeat);
  const lines = scene.nodes.slice(0, -1).map((node, index) => ({
    end: scene.nodes[index + 1],
    start: node,
  }));
  const pulsePoint =
    animationStep === 2
      ? interpolatePoint(scene.nodes[1], scene.nodes[3], motionBeat === 0 ? 0.32 : 0.72)
      : animationStep === 4
      ? interpolatePoint(scene.nodes[3], scene.nodes[5], motionBeat === 0 ? 0.28 : 0.78)
      : null;
  const eyeRadiusY = pose.blink ? 1.2 : 6.5;
  const pupilRadius = 3.4 * pose.pupilScale;
  const armActive = ['write', 'tap', 'raise-hand', 'withdraw'].includes(scene.motionType);
  const legActive = ['run', 'step', 'kick'].includes(scene.motionType);
  const faceActive = ['speak', 'sneeze', 'cough', 'blink', 'pupil'].includes(scene.motionType);
  const chestActive = ['sneeze', 'cough'].includes(scene.motionType) && animationStep >= 5;
  const markerNodes = scene.nodes.map((bodyPoint, index) => ({
    bodyPoint,
    markerPoint: getMarkerPoint(index),
  }));

  return (
    <div className="bg-white/90 rounded-[2rem] border-2 border-blue-200 p-4 md:p-6 shadow-inner">
      <p className="text-sm font-black text-blue-600 mb-2">사람 몸에서 일어나는 실제 반응 애니메이션</p>
      <p className="text-sm font-bold text-gray-600 mb-4">
        자극이 들어온 뒤 신경 신호가 어디를 지나고, 어느 신체 부위가 실제로 움직이는지 보여줍니다.
      </p>

      <svg viewBox="0 0 520 390" className="w-full h-auto rounded-[1.5rem] bg-gradient-to-br from-slate-50 via-cyan-50 to-purple-50 border border-blue-100">
        <defs>
          <linearGradient id="signalLine" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#22d3ee" />
            <stop offset="55%" stopColor="#2563eb" />
            <stop offset="100%" stopColor="#7c3aed" />
          </linearGradient>
        </defs>

        <rect x="28" y="24" width="464" height="338" rx="28" fill="rgba(255,255,255,0.72)" />

        {lines.map((segment, index) => {
          const isCompleted = index < animationStep;
          return (
            <line
              key={`line-${index}`}
              x1={segment.start.x}
              y1={segment.start.y}
              x2={segment.end.x}
              y2={segment.end.y}
              stroke={isCompleted ? 'url(#signalLine)' : '#cbd5e1'}
              strokeWidth={isCompleted ? 8 : 5}
              strokeLinecap="round"
              opacity={isCompleted ? 1 : 0.9}
            />
          );
        })}

        <ellipse
          cx="250"
          cy="178"
          rx="50"
          ry={32 * pose.chestScale}
          fill={chestActive ? 'rgba(56, 189, 248, 0.18)' : 'rgba(148, 163, 184, 0.08)'}
        />
        <line x1="250" y1="118" x2="250" y2="248" stroke="#94a3b8" strokeWidth="18" strokeLinecap="round" />
        <rect x="214" y="118" width="72" height="104" rx="34" fill="#e2e8f0" stroke="#64748b" strokeWidth="4" />
        <line x1="250" y1="120" x2="250" y2="220" stroke={animationStep >= 3 ? '#2563eb' : '#94a3b8'} strokeWidth="6" strokeLinecap="round" />

        <circle cx="250" cy="80" r="38" fill="#f8fafc" stroke="#475569" strokeWidth="4" />
        <ellipse cx="250" cy="70" rx="17" ry="11" fill={animationStep >= 3 ? '#a5b4fc' : '#cbd5e1'} />
        <ellipse cx="238" cy="82" rx="9" ry={eyeRadiusY} fill="#ffffff" stroke="#0f172a" strokeWidth="2" />
        <ellipse cx="262" cy="82" rx="9" ry={eyeRadiusY} fill="#ffffff" stroke="#0f172a" strokeWidth="2" />
        {!pose.blink ? (
          <>
            <circle cx="238" cy="82" r={pupilRadius} fill="#0f172a" />
            <circle cx="262" cy="82" r={pupilRadius} fill="#0f172a" />
          </>
        ) : (
          <>
            <line x1="229" y1="82" x2="247" y2="82" stroke="#0f172a" strokeWidth="2.5" strokeLinecap="round" />
            <line x1="253" y1="82" x2="271" y2="82" stroke="#0f172a" strokeWidth="2.5" strokeLinecap="round" />
          </>
        )}
        <path
          d={`M 238 105 Q 250 ${105 + pose.mouthCurve + pose.mouthHeight} 262 105`}
          fill="none"
          stroke={faceActive && animationStep >= 5 ? '#ef4444' : '#0f172a'}
          strokeWidth={3.2 + pose.mouthHeight * 0.1}
          strokeLinecap="round"
        />

        <LimbChain
          activeColor="#38bdf8"
          anchorX={222}
          anchorY={142}
          isActive={armActive && animationStep >= 5}
          rotation={pose.leftArm}
        />
        <LimbChain
          activeColor="#2563eb"
          anchorX={278}
          anchorY={142}
          isActive={(armActive || faceActive) && animationStep >= 5}
          rotation={pose.rightArm}
        />
        <LimbChain
          activeColor="#14b8a6"
          anchorX={238}
          anchorY={220}
          isActive={legActive && animationStep >= 5}
          length1={48}
          length2={44}
          rotation={pose.leftLeg}
        />
        <LimbChain
          activeColor="#0ea5e9"
          anchorX={262}
          anchorY={220}
          isActive={legActive && animationStep >= 5}
          length1={48}
          length2={44}
          rotation={pose.rightLeg}
        />

        {scene.nodes.map((node, index) => {
          const isCurrent = index === animationStep;
          const isCompleted = index < animationStep;
          const fill = isCurrent ? '#2563eb' : isCompleted ? '#10b981' : '#ffffff';
          const stroke = isCurrent ? '#1d4ed8' : isCompleted ? '#059669' : '#94a3b8';

          return (
            <g key={`node-${index}`} transform={`translate(${node.x} ${node.y})`}>
              <circle r={isCurrent ? 9 : 7} fill={fill} stroke={stroke} strokeWidth="3" />
            </g>
          );
        })}

        {pulsePoint && (
          <>
            <circle cx={pulsePoint.x} cy={pulsePoint.y} r="14" fill="rgba(34,211,238,0.25)" />
            <circle cx={pulsePoint.x} cy={pulsePoint.y} r="8" fill="#22d3ee" stroke="#1d4ed8" strokeWidth="3" />
          </>
        )}

        {scene.motionType === 'speak' && animationStep >= 6 && (
          <>
            <path d="M 292 98 Q 318 88 340 98" fill="none" stroke="#f97316" strokeWidth="4" strokeLinecap="round" />
            <path d="M 302 112 Q 334 104 356 114" fill="none" stroke="#fb7185" strokeWidth="4" strokeLinecap="round" />
          </>
        )}
        {scene.motionType === 'sneeze' && animationStep >= 6 && (
          <>
            <path d="M 292 98 Q 330 72 362 102" fill="none" stroke="#06b6d4" strokeWidth="5" strokeLinecap="round" />
            <path d="M 304 118 Q 344 102 370 128" fill="none" stroke="#38bdf8" strokeWidth="4" strokeLinecap="round" />
          </>
        )}
        {scene.motionType === 'cough' && animationStep >= 6 && (
          <>
            <path d="M 292 102 Q 322 88 350 108" fill="none" stroke="#f97316" strokeWidth="5" strokeLinecap="round" />
            <path d="M 304 122 Q 336 118 362 132" fill="none" stroke="#f59e0b" strokeWidth="4" strokeLinecap="round" />
          </>
        )}
        {scene.motionType === 'raise-hand' && animationStep >= 6 && (
          <>
            <path d="M 310 70 Q 334 54 350 68" fill="none" stroke="#22c55e" strokeWidth="4" strokeLinecap="round" />
            <path d="M 312 88 Q 344 86 356 62" fill="none" stroke="#22c55e" strokeWidth="4" strokeLinecap="round" />
          </>
        )}
        {scene.motionType === 'run' && animationStep >= 6 && (
          <>
            <path d="M 304 318 Q 332 302 356 318" fill="none" stroke="#22c55e" strokeWidth="4" strokeLinecap="round" />
            <path d="M 182 320 Q 160 306 138 320" fill="none" stroke="#22c55e" strokeWidth="4" strokeLinecap="round" />
          </>
        )}
        {scene.motionType === 'withdraw' && animationStep >= 6 && (
          <>
            <path d="M 298 188 Q 330 178 354 188" fill="none" stroke="#fb7185" strokeWidth="4" strokeLinecap="round" />
          </>
        )}

        {markerNodes.map(({ bodyPoint, markerPoint }, index) => {
          const isCurrent = index === animationStep;
          const isCompleted = index < animationStep;
          const side = markerPoint.side;
          const chipWidth = side === 'center' ? 112 : 130;
          const chipX = side === 'left' ? 0 : side === 'right' ? -chipWidth : -(chipWidth / 2);
          const iconX = side === 'right' ? chipX + chipWidth - 18 : chipX + 18;
          const labelX =
            side === 'center'
              ? chipX + chipWidth / 2
              : side === 'right'
                ? chipX + chipWidth - 38
                : chipX + 38;
          const textAnchor = side === 'center' ? 'middle' : side === 'right' ? 'end' : 'start';
          const chipFill = isCurrent
            ? '#2563eb'
            : isCompleted
              ? '#dcfce7'
              : 'rgba(255,255,255,0.96)';
          const chipStroke = isCurrent ? '#1d4ed8' : isCompleted ? '#22c55e' : '#cbd5e1';
          const labelColor = isCurrent ? '#ffffff' : isCompleted ? '#166534' : '#334155';
          const badgeFill = isCurrent ? '#ffffff' : isCompleted ? '#10b981' : '#e2e8f0';
          const badgeText = isCurrent ? '#2563eb' : isCompleted ? '#ffffff' : '#475569';

          return (
            <g key={`marker-${index}`}>
              <line
                x1={bodyPoint.x}
                y1={bodyPoint.y}
                x2={markerPoint.x}
                y2={markerPoint.y}
                stroke={isCurrent ? '#60a5fa' : isCompleted ? '#34d399' : '#cbd5e1'}
                strokeWidth="2.5"
                strokeDasharray="5 6"
                opacity="0.95"
              />
              <g transform={`translate(${markerPoint.x} ${markerPoint.y})`}>
                <rect
                  x={chipX}
                  y="-17"
                  width={chipWidth}
                  height="34"
                  rx="17"
                  fill={chipFill}
                  stroke={chipStroke}
                  strokeWidth="2.5"
                />
                <circle cx={iconX} cy="0" r="11" fill={badgeFill} />
                <text
                  x={iconX}
                  y="1"
                  textAnchor="middle"
                  dominantBaseline="middle"
                  fontSize="11"
                  fontWeight="800"
                  fill={badgeText}
                >
                  {index + 1}
                </text>
                <text
                  x={labelX}
                  y="1"
                  textAnchor={textAnchor}
                  dominantBaseline="middle"
                  fontSize="11"
                  fontWeight="800"
                  fill={labelColor}
                >
                  {getSignalStageLabel(index)}
                </text>
              </g>
            </g>
          );
        })}
      </svg>

      <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-7 gap-3 mt-4">
        {problem.animationSteps.map((step, index) => {
          const isCurrent = index === animationStep;
          const isCompleted = index < animationStep;

          return (
            <div
              key={`${step.label}-${index}`}
              className={`rounded-2xl border-2 p-3 text-center transition-all ${
                isCurrent
                  ? 'bg-gradient-to-br from-blue-500 to-purple-500 text-white border-blue-500 shadow-lg'
                  : isCompleted
                    ? 'bg-gradient-to-br from-emerald-100 to-green-50 text-emerald-900 border-emerald-300'
                    : 'bg-white text-gray-500 border-gray-200'
              }`}
            >
              <p className="text-xs font-black opacity-80 mb-1">{getSignalStageLabel(index)}</p>
              <div className="text-2xl mb-1">{step.icon}</div>
              <p className="text-xs font-black leading-tight">{step.label}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function VideoSignalScene({ animationStep, problem, setAnimationStep, isPlaying, setIsPlaying }) {
  const videoRef = useRef(null);
  const [videoDuration, setVideoDuration] = useState(0);
  const stepCount = problem.animationSteps.length;

  useEffect(() => {
    const video = videoRef.current;
    if (!video) {
      return undefined;
    }

    video.currentTime = 0;
    video.load();

    return undefined;
  }, [problem.id, problem.videoSrc]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) {
      return undefined;
    }

    if (isPlaying) {
      video.play().catch(() => {
        setIsPlaying(false);
      });
    } else {
      video.pause();
    }

    return undefined;
  }, [isPlaying, problem.id, setIsPlaying]);

  const seekToStep = (nextStep) => {
    const video = videoRef.current;

    if (video && videoDuration) {
      video.currentTime = getVideoSeekTime(nextStep, videoDuration, stepCount);
    }

    setAnimationStep(nextStep);
  };

  const handleLoadedMetadata = (event) => {
    const duration = event.currentTarget.duration || 0;
    setVideoDuration(duration);
    setAnimationStep(0);
  };

  const handleTimeUpdate = (event) => {
    const video = event.currentTarget;

    if (!video.duration) {
      return;
    }

    setAnimationStep(getVideoStepFromTime(video.currentTime, video.duration, stepCount));
  };

  const handleEnded = () => {
    setAnimationStep(stepCount - 1);
    setIsPlaying(false);
  };

  return (
    <div className="bg-white/90 rounded-[2rem] border-2 border-blue-200 p-4 md:p-6 shadow-inner">
      <p className="text-sm font-black text-blue-600 mb-2">문제 장면 애니메이션</p>
      <p className="text-sm font-bold text-gray-600 mb-4">
        교사와 학생이 같은 장면 영상을 보면서 신호 전달 단계와 최종 반응을 함께 확인합니다.
      </p>

      <div className="rounded-[1.5rem] overflow-hidden border-2 border-blue-100 bg-slate-950 shadow-xl">
        <video
          ref={videoRef}
          className="w-full h-auto block"
          muted
          playsInline
          preload="auto"
          src={problem.videoSrc}
          onEnded={handleEnded}
          onLoadedMetadata={handleLoadedMetadata}
          onTimeUpdate={handleTimeUpdate}
        />
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-7 gap-3 mt-4">
        {problem.animationSteps.map((step, index) => {
          const isCurrent = index === animationStep;
          const isCompleted = index < animationStep;

          return (
            <div
              key={`${step.label}-${index}`}
              className={`rounded-2xl border-2 p-3 text-center transition-all ${
                isCurrent
                  ? 'bg-gradient-to-br from-blue-500 to-purple-500 text-white border-blue-500 shadow-lg'
                  : isCompleted
                    ? 'bg-gradient-to-br from-emerald-100 to-green-50 text-emerald-900 border-emerald-300'
                    : 'bg-white text-gray-500 border-gray-200'
              }`}
            >
              <p className="text-xs font-black opacity-80 mb-1">{getSignalStageLabel(index)}</p>
              <div className="text-2xl mb-1">{step.icon}</div>
              <p className="text-xs font-black leading-tight">{step.label}</p>
            </div>
          );
        })}
      </div>

      <div className="mt-4 grid grid-cols-1 md:grid-cols-4 gap-4">
        <button
          onClick={() => {
            seekToStep(0);
            setIsPlaying(false);
          }}
          className="bg-white text-gray-800 font-black py-3 px-4 rounded-lg border-2 border-gray-300 hover:bg-gray-100 transition-all"
        >
          ⏮️ 처음
        </button>
        <button
          onClick={() => setIsPlaying(!isPlaying)}
          className="bg-blue-500 text-white font-black py-3 px-4 rounded-lg hover:bg-blue-600 transition-all"
        >
          {isPlaying ? '⏸️ 정지' : '▶️ 재생'}
        </button>
        <button
          onClick={() => {
            if (animationStep > 0) {
              seekToStep(animationStep - 1);
            }
            setIsPlaying(false);
          }}
          className="bg-yellow-500 text-white font-black py-3 px-4 rounded-lg hover:bg-yellow-600 transition-all"
        >
          ⬅️ 이전
        </button>
        <button
          onClick={() => {
            if (animationStep < stepCount - 1) {
              seekToStep(animationStep + 1);
            }
            setIsPlaying(false);
          }}
          className="bg-yellow-500 text-white font-black py-3 px-4 rounded-lg hover:bg-yellow-600 transition-all"
        >
          다음 ➡️
        </button>
      </div>
    </div>
  );
}

function NeuralSignalAnimation({
  allowNext = false,
  footerMessage,
  onNext = () => {},
  problem,
  showAdvanceButton = true,
}) {
  const [animationStep, setAnimationStep] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const animationIntervalRef = useRef(null);
  const hasVideo = Boolean(problem.videoSrc);

  useEffect(() => {
    setAnimationStep(0);
    setIsPlaying(true);
  }, [hasVideo, problem.id]);

  useEffect(() => {
    if (hasVideo) {
      return undefined;
    }

    if (!isPlaying) return undefined;

    animationIntervalRef.current = setInterval(() => {
      setAnimationStep((prev) => {
        if (prev < problem.animationSteps.length - 1) {
          return prev + 1;
        }

        setIsPlaying(false);
        return prev;
      });
    }, 2100);

    return () => clearInterval(animationIntervalRef.current);
  }, [hasVideo, isPlaying, problem.animationSteps.length]);

  const currentStep = problem.animationSteps[animationStep];
  const progressPercent = ((animationStep + 1) / problem.animationSteps.length) * 100;
  const responseSummary = getBodyResponseSummary(problem);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-400 to-pink-400 p-4 py-6">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-3xl shadow-2xl p-6 md:p-8">
          <h1 className="text-3xl md:text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600 mb-2 text-center">
            {problem.title}
          </h1>
          <p className="text-center text-gray-600 font-bold mb-6">{problem.description}</p>

          <div className="grid grid-cols-1 xl:grid-cols-[1.35fr_0.65fr] gap-6 mb-6">
            {hasVideo ? (
              <VideoSignalScene
                animationStep={animationStep}
                isPlaying={isPlaying}
                problem={problem}
                setAnimationStep={setAnimationStep}
                setIsPlaying={setIsPlaying}
              />
            ) : (
              <HumanSignalScene animationStep={animationStep} problem={problem} />
            )}

            <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-3xl p-6 border-2 border-green-200 flex flex-col gap-5">
              <div className="bg-white rounded-2xl border-2 border-green-200 p-4">
                <p className="text-sm font-black text-green-700 mb-2">현재 활성화된 단계</p>
                <div className="flex items-center gap-4">
                  <div className="h-16 w-16 rounded-2xl bg-gradient-to-br from-green-400 to-emerald-500 text-white flex items-center justify-center text-3xl font-black shadow-lg">
                    {currentStep.icon}
                  </div>
                  <div>
                    <p className="text-sm font-black text-gray-500">{getSignalStageLabel(animationStep)}</p>
                    <h3 className="text-2xl font-black text-gray-800">{currentStep.label}</h3>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-2xl border-2 border-purple-200 p-4">
                <p className="text-sm font-black text-purple-700 mb-2">몸에서 일어나는 일</p>
                <p className="text-base font-bold text-gray-700 leading-relaxed">
                  {getSignalPhaseText(problem, animationStep, currentStep)}
                </p>
              </div>

              <div className="bg-white rounded-2xl border-2 border-orange-200 p-4">
                <p className="text-sm font-black text-orange-700 mb-2">최종 반응 설명</p>
                <p className="text-base font-bold text-gray-700 leading-relaxed">{responseSummary}</p>
              </div>

              <div className="bg-white rounded-2xl border-2 border-blue-200 p-4">
                <div className="flex items-center justify-between text-sm font-black text-blue-700 mb-2">
                  <span>애니메이션 진행도</span>
                  <span>{animationStep + 1} / {problem.animationSteps.length}</span>
                </div>
                <div className="h-3 rounded-full bg-blue-100 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 transition-all duration-700"
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
              </div>

              <div className="bg-white rounded-2xl border-2 border-emerald-200 p-4">
                <p className="text-sm font-black text-emerald-700 mb-2">
                  {problem.type === 'unconditional' ? '반사 특징' : '의식 반응 특징'}
                </p>
                <p className="text-sm font-bold text-gray-700 leading-relaxed">
                  {getSignalModeSummary(problem)}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-blue-100 to-purple-100 rounded-2xl p-6 border-2 border-blue-300">
            {!hasVideo && (
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                <button
                  onClick={() => {
                    setAnimationStep(0);
                    setIsPlaying(false);
                  }}
                  className="bg-white text-gray-800 font-black py-3 px-4 rounded-lg border-2 border-gray-300 hover:bg-gray-100 transition-all"
                >
                  ⏮️ 처음
                </button>
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="bg-blue-500 text-white font-black py-3 px-4 rounded-lg hover:bg-blue-600 transition-all"
                >
                  {isPlaying ? '⏸️ 정지' : '▶️ 재생'}
                </button>
                <button
                  onClick={() => {
                    if (animationStep > 0) {
                      setAnimationStep(animationStep - 1);
                    }
                    setIsPlaying(false);
                  }}
                  className="bg-yellow-500 text-white font-black py-3 px-4 rounded-lg hover:bg-yellow-600 transition-all"
                >
                  ⬅️ 이전
                </button>
                <button
                  onClick={() => {
                    if (animationStep < problem.animationSteps.length - 1) {
                      setAnimationStep(animationStep + 1);
                    }
                    setIsPlaying(false);
                  }}
                  className="bg-yellow-500 text-white font-black py-3 px-4 rounded-lg hover:bg-yellow-600 transition-all"
                >
                  다음 ➡️
                </button>
              </div>
            )}

            <div className="bg-yellow-50 border-2 border-yellow-300 rounded-lg p-3 mb-4">
              <p className="text-sm font-bold text-yellow-800 text-center">
                {footerMessage || (allowNext ? '✅ 다음 문제로 진행 가능합니다!' : '⏳ 교사의 허용을 기다리고 있습니다...')}
              </p>
            </div>

            {showAdvanceButton && (
              <button
                onClick={onNext}
                disabled={!allowNext}
                className={`w-full font-black py-4 px-6 rounded-lg text-lg transition-all ${
                  allowNext
                    ? 'bg-gradient-to-r from-green-500 to-emerald-500 text-white hover:shadow-lg'
                    : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                }`}
              >
                ✓ 다음 문제로
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
