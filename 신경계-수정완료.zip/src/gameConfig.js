export const TEAM_COUNT = 8;
export const TOTAL_QUESTIONS = 6;
export const QUESTION_DURATION_SECONDS = 60;
export const SESSION_POLL_INTERVAL_MS = 2000;

export const createEmptyAnswers = () => {
  const answers = {};

  for (let teamNumber = 1; teamNumber <= TEAM_COUNT; teamNumber += 1) {
    answers[String(teamNumber)] = Array(TOTAL_QUESTIONS).fill(null);
  }

  return answers;
};

export const createEmptyScores = () => {
  const scores = {};

  for (let teamNumber = 1; teamNumber <= TEAM_COUNT; teamNumber += 1) {
    scores[String(teamNumber)] = Array(TOTAL_QUESTIONS).fill(0);
  }

  return scores;
};

export const getDefaultTeamName = (teamNumber) => `${teamNumber}모둠`;
