import { getStore } from '@netlify/blobs';
import {
  createEmptyAnswers,
  createEmptyScores,
  getDefaultTeamName,
  QUESTION_DURATION_SECONDS,
  TEAM_COUNT,
  TOTAL_QUESTIONS,
} from '../../src/gameConfig.js';
import { correctSequencesByActivity } from '../../src/problemMeta.js';

const sessionStore = getStore('neuron-mission-sessions');
const sessionCodeAlphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      'Cache-Control': 'no-store',
      'Content-Type': 'application/json; charset=utf-8',
    },
  });
}

function normalizeSessionCode(value) {
  return String(value || '')
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, '')
    .slice(0, 6);
}

function getSessionKey(code) {
  return `session:${code}`;
}

function buildDeadline() {
  return new Date(Date.now() + QUESTION_DURATION_SECONDS * 1000).toISOString();
}

function deepClone(value) {
  return JSON.parse(JSON.stringify(value));
}

function wasModified(result) {
  // Some Netlify runtimes complete the write but don't return the full result object.
  // Treat an explicit `modified: false` as the only retry/failure signal here.
  return result?.modified !== false;
}

function sanitizeTeamNames(teamNames) {
  const nextTeamNames = {};

  for (let teamNumber = 1; teamNumber <= TEAM_COUNT; teamNumber += 1) {
    const providedName = teamNames?.[teamNumber] || teamNames?.[String(teamNumber)] || '';
    nextTeamNames[String(teamNumber)] = String(providedName).trim() || getDefaultTeamName(teamNumber);
  }

  return nextTeamNames;
}

function sanitizeSequence(sequence) {
  if (!Array.isArray(sequence)) {
    return [];
  }

  return sequence.slice(0, 7).map((card, index) => ({
    id: Number(card?.id ?? index + 1),
    text: String(card?.text || '').trim(),
    type: card?.type === 'trap' ? 'trap' : 'correct',
  }));
}

function calculateScore(sequence, correctSequence, submittedAt, deadlineAt) {
  let score = 0;

  const hasAllCorrectCards = correctSequence.every((card) =>
    sequence.some((selectedCard) => selectedCard.text === card),
  );

  if (hasAllCorrectCards && sequence.length === correctSequence.length) {
    score += 1;
  }

  const submittedSequence = sequence.map((card) => card.text);
  const isCorrect = JSON.stringify(submittedSequence) === JSON.stringify(correctSequence);

  if (isCorrect) {
    score += 6;
  }

  const hasTrapCard = sequence.some((card) => card.type === 'trap');
  if (!hasTrapCard) {
    score += 1;
  }

  if (
    deadlineAt &&
    Number.isFinite(new Date(deadlineAt).getTime()) &&
    new Date(submittedAt).getTime() <= new Date(deadlineAt).getTime()
  ) {
    score += 2;
  }

  return {
    isCorrect,
    score,
  };
}

async function readSession(code) {
  return sessionStore.get(getSessionKey(code), {
    consistency: 'strong',
    type: 'json',
  });
}

async function updateSession(code, updater) {
  const sessionKey = getSessionKey(code);

  for (let attempt = 0; attempt < 5; attempt += 1) {
    const storedEntry = await sessionStore.getWithMetadata(sessionKey, {
      consistency: 'strong',
      type: 'json',
    });

    if (storedEntry === null) {
      return null;
    }

    const workingCopy = deepClone(storedEntry.data);
    const nextSession = updater(workingCopy);
    nextSession.updatedAt = new Date().toISOString();

    const result = await sessionStore.setJSON(sessionKey, nextSession, {
      onlyIfMatch: storedEntry.etag,
    });

    if (wasModified(result)) {
      return nextSession;
    }
  }

  throw new Error('세션이 동시에 수정되어 다시 시도해 주세요.');
}

async function createNewSession(payload) {
  const activityTab = payload?.activityTab === 'unconditional' ? 'unconditional' : 'conscious';
  const teamNames = sanitizeTeamNames(payload?.teamNames);

  for (let attempt = 0; attempt < 20; attempt += 1) {
    let sessionCode = '';

    for (let index = 0; index < 6; index += 1) {
      const randomIndex = Math.floor(Math.random() * sessionCodeAlphabet.length);
      sessionCode += sessionCodeAlphabet[randomIndex];
    }

    const session = {
      activityTab,
      answers: createEmptyAnswers(),
      createdAt: new Date().toISOString(),
      currentQuestion: 0,
      phase: 'lobby',
      questionDeadlineAt: null,
      scores: createEmptyScores(),
      sessionCode,
      teamNames,
      updatedAt: new Date().toISOString(),
    };

    const result = await sessionStore.setJSON(getSessionKey(sessionCode), session, {
      onlyIfNew: true,
    });

    if (wasModified(result)) {
      return session;
    }
  }

  throw new Error('세션 코드를 만드는 데 실패했습니다.');
}

export default async function handler(request) {
  try {
    if (request.method === 'GET') {
      const url = new URL(request.url);
      const code = normalizeSessionCode(url.searchParams.get('code'));

      if (!code) {
        return json({ error: '세션 코드를 입력해 주세요.' }, 400);
      }

      const session = await readSession(code);

      if (!session) {
        return json({ error: '해당 세션을 찾을 수 없습니다.' }, 404);
      }

      return json({ session });
    }

    if (request.method !== 'POST') {
      return json({ error: '지원하지 않는 요청입니다.' }, 405);
    }

    const body = await request.json().catch(() => null);

    if (!body?.action) {
      return json({ error: '요청 형식이 올바르지 않습니다.' }, 400);
    }

    if (body.action === 'create') {
      const session = await createNewSession(body.payload);
      return json({ session }, 201);
    }

    const code = normalizeSessionCode(body.code);

    if (!code) {
      return json({ error: '세션 코드가 필요합니다.' }, 400);
    }

    if (body.action === 'teacherAction') {
      const updatedSession = await updateSession(code, (session) => {
        switch (body.teacherAction) {
          case 'startGame':
            return {
              ...session,
              currentQuestion: 0,
              phase: 'mission',
              questionDeadlineAt: buildDeadline(),
            };
          case 'showAnimation':
            return {
              ...session,
              phase: 'animation',
              questionDeadlineAt: null,
            };
          case 'nextQuestion':
            if (session.currentQuestion >= TOTAL_QUESTIONS - 1) {
              return {
                ...session,
                phase: 'results',
                questionDeadlineAt: null,
              };
            }

            return {
              ...session,
              currentQuestion: session.currentQuestion + 1,
              phase: 'mission',
              questionDeadlineAt: buildDeadline(),
            };
          case 'showResults':
            return {
              ...session,
              phase: 'results',
              questionDeadlineAt: null,
            };
          case 'restart':
            return {
              ...session,
              answers: createEmptyAnswers(),
              currentQuestion: 0,
              phase: 'lobby',
              questionDeadlineAt: null,
              scores: createEmptyScores(),
            };
          default:
            throw new Error('알 수 없는 교사 작업입니다.');
        }
      });

      if (!updatedSession) {
        return json({ error: '해당 세션을 찾을 수 없습니다.' }, 404);
      }

      return json({ session: updatedSession });
    }

    if (body.action === 'submitAnswer') {
      const teamIndex = Number(body.payload?.teamIdx);
      const teamKey = String(teamIndex);

      if (!Number.isInteger(teamIndex) || teamIndex < 1 || teamIndex > TEAM_COUNT) {
        return json({ error: '모둠 번호가 올바르지 않습니다.' }, 400);
      }

      const updatedSession = await updateSession(code, (session) => {
        const questionIndex = session.currentQuestion;
        const problems =
          correctSequencesByActivity[session.activityTab] || correctSequencesByActivity.conscious;
        const correctSequence = problems[questionIndex];

        if (!correctSequence) {
          throw new Error('문제 정보를 찾을 수 없습니다.');
        }

        const submittedAt = new Date().toISOString();
        const sanitizedSequence = sanitizeSequence(body.payload?.sequence);
        const { isCorrect, score } = calculateScore(
          sanitizedSequence,
          correctSequence,
          submittedAt,
          session.questionDeadlineAt,
        );

        session.answers[teamKey][questionIndex] = {
          isCorrect,
          score,
          sequence: sanitizedSequence,
          submittedAt,
        };
        session.scores[teamKey][questionIndex] = score;

        return session;
      });

      if (!updatedSession) {
        return json({ error: '해당 세션을 찾을 수 없습니다.' }, 404);
      }

      return json({ session: updatedSession });
    }

    return json({ error: '지원하지 않는 작업입니다.' }, 400);
  } catch (error) {
    return json({ error: error.message || '세션 처리 중 오류가 발생했습니다.' }, 500);
  }
}
